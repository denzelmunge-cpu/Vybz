@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vybz.player.ui.screens

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.vybz.player.BuildConfig
import com.vybz.player.data.AppSettings
import com.vybz.player.data.OnlineRepository
import com.vybz.player.ui.MainViewModel
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val s by AppSettings.state.collectAsState()
    val context = LocalContext.current
    var cacheBytes by remember { mutableLongStateOf(OnlineRepository.cacheSizeBytes(context)) }
    var showSpeed by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Settings") },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 16.dp).padding(bottom = 32.dp)
        ) {
            Header("Appearance")
            ThemePicker(s.theme) { t -> AppSettings.update { it.copy(theme = t) } }
            if (Build.VERSION.SDK_INT >= 31) {
                if (s.theme == com.vybz.player.ui.theme.ThemeIds.NEON) {
                    SwitchRow("Material You colours", "Match your wallpaper", s.dynamicColor) { v -> AppSettings.update { it.copy(dynamicColor = v) } }
                }
            }
            SwitchRow(
                if (s.theme == com.vybz.player.ui.theme.ThemeIds.SAFARI) "Safari night (darker)" else "Pure black (AMOLED)",
                "Saves battery on OLED screens", s.pureBlack
            ) { v -> AppSettings.update { it.copy(pureBlack = v) } }

            Header("Playback")
            Column(Modifier.fillMaxWidth().clickable { showSpeed = true }.padding(vertical = 8.dp)) {
                Text("Speed & pitch", style = MaterialTheme.typography.titleMedium)
                Text(
                    String.format(Locale.ROOT, "%.2fx speed · %.2fx pitch — tap to change", s.speed, s.pitch),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(Modifier.fillMaxWidth().clickable { vm.navigate(com.vybz.player.ui.Screen.Sound) }.padding(vertical = 8.dp)) {
                Text("Hi-Res engine & sound", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (s.hqEnabled) "On · 32-bit float output, precision resampling" else "Off · 32-bit float output at the file's rate",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text("Gapless playback is always on. Playback pauses automatically when earphones are unplugged or Bluetooth disconnects.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Header("Library")
            LabeledSlider(
                "Hide tracks shorter than", "${s.minDurationSec}s", s.minDurationSec.toFloat(), 0f..120f
            ) { v -> AppSettings.update { it.copy(minDurationSec = (v / 5).roundToInt() * 5) } }
            OutlinedButton(onClick = { vm.loadLibrary() }, modifier = Modifier.padding(top = 4.dp)) { Text("Rescan music") }

            Header("TV")
            SwitchRow("Ask before using mobile data", "Live TV uses about 0.3–1.5 GB per hour", s.tvWifiOnly) { v ->
                AppSettings.update { it.copy(tvWifiOnly = v) }
            }
            Text("Picture quality", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            androidx.compose.foundation.layout.Row(
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                listOf("Auto", "Data saver", "Best (HD)").forEachIndexed { i, label ->
                    androidx.compose.material3.FilterChip(
                        selected = s.tvQuality == i,
                        onClick = { AppSettings.update { it.copy(tvQuality = i) } },
                        label = { Text(label) }
                    )
                }
            }

            Header("Online (optional)")
            Text("Vybz works fully offline. When allowed, it looks up lyrics (LRCLIB), cover art & genre (iTunes) and artist bios (Wikipedia), then saves them on your phone for offline use.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            SwitchRow("Use internet for music info", "", s.onlineEnabled) { v -> AppSettings.update { it.copy(onlineEnabled = v) } }
            SwitchRow("Wi-Fi only", "Don't use mobile data", s.wifiOnly) { v -> AppSettings.update { it.copy(wifiOnly = v) } }
            SwitchRow("Auto-fetch lyrics", "", s.autoLyrics) { v -> AppSettings.update { it.copy(autoLyrics = v) } }
            SwitchRow("Auto-fetch missing cover art", "", s.autoArtwork) { v -> AppSettings.update { it.copy(autoArtwork = v) } }
            Text(String.format(Locale.ROOT, "Offline cache: %.1f MB", cacheBytes / 1048576.0),
                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = {
                OnlineRepository.clearCache(context); cacheBytes = 0L
            }, modifier = Modifier.padding(top = 4.dp)) { Text("Clear downloaded lyrics & info") }

            Header("About")
            Column(Modifier.fillMaxWidth().clickable { vm.navigate(com.vybz.player.ui.Screen.About) }.padding(vertical = 8.dp)) {
                Text("About, privacy & help", style = MaterialTheme.typography.titleMedium)
                Text("Privacy policy, terms, FAQ, release checklist, your listening stats",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Vybz ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            Text("Formats: MP3, AAC/M4A, FLAC, OGG/Vorbis, Opus, WAV, AMR (device decoders). Engine: Media3 ExoPlayer with 64-bit Vybz DSP.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
        }
    }
    if (showSpeed) SpeedDialog { showSpeed = false }
}

@Composable
private fun Header(text: String) {
    Text(
        text.uppercase(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 4.dp)
    )
}

@Composable
private fun ThemePicker(selected: Int, onPick: (Int) -> Unit) {
    val options = listOf(
        Triple(com.vybz.player.ui.theme.ThemeIds.NEON, "Vybz Neon", listOf(
            androidx.compose.ui.graphics.Color(0xFF9B7BFF), androidx.compose.ui.graphics.Color(0xFFFF4D9D),
            androidx.compose.ui.graphics.Color(0xFF0B0B10))),
        Triple(com.vybz.player.ui.theme.ThemeIds.SAFARI, "Kenyan Safari", listOf(
            com.vybz.player.ui.theme.SafariGold, com.vybz.player.ui.theme.SafariSunset,
            com.vybz.player.ui.theme.SafariAcacia)),
    )
    androidx.compose.foundation.layout.Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)
    ) {
        options.forEach { (id, label, colors) ->
            val isSel = id == selected
            androidx.compose.material3.OutlinedCard(
                onClick = { onPick(id) },
                modifier = Modifier.weight(1f),
                border = androidx.compose.foundation.BorderStroke(
                    if (isSel) 2.dp else 1.dp,
                    if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                )
            ) {
                Column(Modifier.padding(12.dp)) {
                    androidx.compose.foundation.layout.Box(
                        Modifier.fillMaxWidth().height(44.dp)
                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                            .background(androidx.compose.ui.graphics.Brush.horizontalGradient(colors))
                    )
                    Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                    Text(
                        if (id == com.vybz.player.ui.theme.ThemeIds.SAFARI) "Savanna gold, sunset & acacia" else "Violet & pink neon",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
