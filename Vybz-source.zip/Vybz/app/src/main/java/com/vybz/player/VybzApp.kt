package com.vybz.player

import android.app.Application
import com.vybz.player.audio.AudioEngine
import com.vybz.player.data.AppSettings
import com.vybz.player.data.ListeningStats

class VybzApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppSettings.init(this)
        AudioEngine.init(this)
        ListeningStats.init(this)
        com.vybz.player.data.RadioRepository.init(this)
        com.vybz.player.data.TvRepository.init(this)
    }
}
