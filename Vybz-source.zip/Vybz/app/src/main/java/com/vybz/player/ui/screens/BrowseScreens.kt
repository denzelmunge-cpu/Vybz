@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.vybz.player.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.vybz.player.data.ArtistInfo
import com.vybz.player.data.OnlineRepository
import com.vybz.player.ui.MainViewModel
import com.vybz.player.ui.Screen
import com.vybz.player.ui.components.Artwork
import com.vybz.player.ui.components.SectionHeader
import com.vybz.player.ui.components.SongRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(vm: MainViewModel) {
    val lib by vm.library.collectAsState()
    val player by vm.player.collectAsState()
    var q by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (e: Exception) { } }

    val query = q.trim()
    val songs = remember(query, lib) {
        if (query.isEmpty()) emptyList() else lib.songs.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }.take(100)
    }
    val albums = remember(query, lib) {
        if (query.isEmpty()) emptyList() else lib.albums.filter {
            it.title.contains(query, true) || it.artist.contains(query, true)
        }.take(20)
    }
    val artists = remember(query, lib) {
        if (query.isEmpty()) emptyList() else lib.artists.filter { it.name.contains(query, true) }.take(20)
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                placeholder = { Text("Songs, artists, albums") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Rounded.Close, "Clear") }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier.weight(1f).focusRequester(focus)
            )
        }
        LazyColumn(Modifier.fillMaxSize()) {
            if (artists.isNotEmpty()) {
                item { SectionHeader("Artists") }
                items(artists, key = { "ar_" + it.name }) { a ->
                    ListRow(a.name, "${a.songs.size} songs", leading = {
                        Artwork(a.songs.first(), Modifier.size(48.dp), sizePx = 150, corner = 24.dp)
                    }) { vm.navigate(Screen.Collection(a.name, "${a.songs.size} songs", a.songs, a.name)) }
                }
            }
            if (albums.isNotEmpty()) {
                item { SectionHeader("Albums") }
                items(albums, key = { "al_" + it.id }) { al ->
                    ListRow(al.title, al.artist, leading = {
                        Artwork(al.songs.first(), Modifier.size(48.dp), sizePx = 150, corner = 8.dp)
                    }) { vm.navigate(Screen.Collection(al.title, al.artist, al.songs)) }
                }
            }
            if (songs.isNotEmpty()) {
                item { SectionHeader("Songs") }
                itemsIndexed(songs, key = { _, s -> "s_" + s.key }) { i, s ->
                    SongRow(
                        s, s.key == player.song?.key,
                        onClick = { vm.playSongs(songs, i) },
                        onPlayNext = { vm.playNext(s) },
                        onAddToQueue = { vm.addToQueue(s) },
                        onGoToArtist = { goToArtist(vm, s) },
                    )
                }
            }
            if (query.isNotEmpty() && songs.isEmpty() && albums.isEmpty() && artists.isEmpty()) {
                item {
                    Text(
                        "Nothing matches \"$query\"",
                        modifier = Modifier.padding(24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectionScreen(vm: MainViewModel, screen: Screen.Collection) {
    val player by vm.player.collectAsState()
    val context = LocalContext.current
    var artistInfo by remember(screen.artistName) { mutableStateOf<ArtistInfo?>(null) }
    var bioExpanded by remember { mutableStateOf(false) }
    val artistName = screen.artistName
    if (artistName != null) {
        LaunchedEffect(artistName) {
            artistInfo = OnlineRepository.artistInfo(context, artistName)
        }
    }
    val songs = screen.songs

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(screen.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                IconButton(onClick = { vm.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Artwork(songs.firstOrNull(), Modifier.size(120.dp), sizePx = 400, corner = 16.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(screen.title, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            screen.subtitle, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.size(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.playSongs(songs) }) {
                                Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp)); Text("Play")
                            }
                            FilledTonalButton(onClick = { vm.playSongs(songs, shuffle = true) }) {
                                Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
            val bio = artistInfo?.bio.orEmpty()
            if (bio.isNotBlank()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                        Text("About", style = MaterialTheme.typography.titleMedium)
                        Text(
                            bio,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = if (bioExpanded) Int.MAX_VALUE else 4,
                            overflow = TextOverflow.Ellipsis,
                        )
                        androidx.compose.material3.TextButton(onClick = { bioExpanded = !bioExpanded }) {
                            Text(if (bioExpanded) "Less" else "More · Wikipedia")
                        }
                    }
                }
            }
            itemsIndexed(songs, key = { _, s -> s.key }) { i, s ->
                SongRow(
                    s, s.key == player.song?.key,
                    onClick = { vm.playSongs(songs, i) },
                    onPlayNext = { vm.playNext(s) },
                    onAddToQueue = { vm.addToQueue(s) },
                )
            }
        }
    }
}
