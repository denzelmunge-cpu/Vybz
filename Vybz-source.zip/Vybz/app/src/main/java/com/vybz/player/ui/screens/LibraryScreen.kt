@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.vybz.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vybz.player.data.Song
import com.vybz.player.ui.MainViewModel
import com.vybz.player.ui.Screen
import com.vybz.player.ui.SortMode
import com.vybz.player.ui.components.Artwork
import com.vybz.player.ui.components.SongRow
import com.vybz.player.ui.theme.VybzPink
import com.vybz.player.ui.theme.VybzViolet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(vm: MainViewModel) {
    val lib by vm.library.collectAsState()
    val loading by vm.loading.collectAsState()
    val player by vm.player.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf("Songs", "Albums", "Artists", "Folders", "Radio", "TV")

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.foundation.Image(
                        androidx.compose.ui.res.painterResource(com.vybz.player.R.drawable.vybz_mark),
                        contentDescription = "Vybz logo",
                        modifier = Modifier.height(30.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "VYBZ",
                        style = TextStyle(
                            color = androidx.compose.ui.graphics.Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            letterSpacing = 5.sp
                        )
                    )
                }
            },
            actions = {
                IconButton(onClick = { vm.navigate(Screen.Search) }) { Icon(Icons.Rounded.Search, "Search") }
                IconButton(onClick = { vm.navigate(Screen.Sound) }) { Icon(Icons.Rounded.Equalizer, "Sound") }
                IconButton(onClick = { vm.navigate(Screen.Settings) }) { Icon(Icons.Rounded.Settings, "Settings") }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
        com.vybz.player.ui.theme.SafariStripe()
        ScrollableTabRow(
            selectedTabIndex = tab,
            containerColor = MaterialTheme.colorScheme.background,
            edgePadding = 8.dp,
        ) {
            tabs.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }

        if (tab == 4) {
            RadioTab(vm)
        } else if (tab == 5) {
            TvTab(vm)
        } else if (loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else if (lib.songs.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No music found", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.size(8.dp))
                Text(
                    "Copy songs (MP3, FLAC, AAC, M4A, OGG, OPUS, WAV) to your phone, then tap rescan.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(16.dp))
                Button(onClick = { vm.loadLibrary() }) { Text("Rescan") }
            }
        } else when (tab) {
            0 -> {
                val sorted = remember(lib.songs, vm.sortMode) { vm.sortedSongs(lib.songs) }
                SongsTab(vm, sorted, player.song?.key)
            }
            1 -> LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(lib.albums, key = { it.id }) { album ->
                    Column(Modifier.clickable {
                        vm.navigate(Screen.Collection(album.title, "${album.artist} · ${album.songs.size} songs", album.songs))
                    }) {
                        Artwork(album.songs.first(), Modifier.fillMaxWidth().aspectRatio(1f), sizePx = 400, corner = 14.dp)
                        Text(
                            album.title, style = MaterialTheme.typography.titleMedium, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp)
                        )
                        Text(
                            album.artist, style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            2 -> LazyColumn(Modifier.fillMaxSize()) {
                items(lib.artists, key = { it.name }) { artist ->
                    ListRow(
                        title = artist.name,
                        subtitle = "${artist.songs.size} songs · ${artist.albumCount} albums",
                        leading = { Artwork(artist.songs.first(), Modifier.size(52.dp).clip(CircleShape), sizePx = 150, corner = 26.dp) },
                        onClick = {
                            vm.navigate(Screen.Collection(artist.name, "${artist.songs.size} songs", artist.songs, artistName = artist.name))
                        }
                    )
                }
            }
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(lib.folders, key = { it.path }) { folder ->
                    ListRow(
                        title = folder.name,
                        subtitle = "${folder.songs.size} songs · ${folder.path}",
                        leading = {
                            Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                            }
                        },
                        onClick = { vm.navigate(Screen.Collection(folder.name, folder.path, folder.songs)) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SongsTab(vm: MainViewModel, songs: List<Song>, currentKey: String?) {
    var sortMenu by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = { vm.playSongs(songs, shuffle = true) }) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Shuffle all · ${songs.size}")
                }
                Spacer(Modifier.weight(1f))
                Box {
                    TextButton(onClick = { sortMenu = true }) {
                        Icon(Icons.Rounded.Sort, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(vm.sortMode.label)
                    }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        SortMode.values().forEach { m ->
                            DropdownMenuItem(text = { Text(m.label) }, onClick = { vm.sortMode = m; sortMenu = false })
                        }
                    }
                }
            }
        }
        itemsIndexed(songs, key = { _, s -> s.key }) { i, s ->
            SongRow(
                song = s,
                isCurrent = s.key == currentKey,
                onClick = { vm.playSongs(songs, i) },
                onPlayNext = { vm.playNext(s) },
                onAddToQueue = { vm.addToQueue(s) },
                onGoToArtist = { goToArtist(vm, s) },
            )
        }
    }
}

fun goToArtist(vm: MainViewModel, s: Song) {
    val name = com.vybz.player.data.MusicRepository.primaryArtist(s.artist)
    val artist = vm.library.value.artists.firstOrNull { it.name == name } ?: return
    vm.navigate(Screen.Collection(artist.name, "${artist.songs.size} songs", artist.songs, artistName = artist.name))
}

@Composable
fun ListRow(title: String, subtitle: String, leading: @Composable () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                subtitle, style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
