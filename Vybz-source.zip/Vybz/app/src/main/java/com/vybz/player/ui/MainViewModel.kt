package com.vybz.player.ui

import android.app.Application
import android.content.ComponentName
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.vybz.player.data.AppSettings
import com.vybz.player.data.ArtistInfo
import com.vybz.player.data.ArtworkLoader
import com.vybz.player.data.Library
import com.vybz.player.data.Lyrics
import com.vybz.player.data.MusicRepository
import com.vybz.player.data.OnlineRepository
import com.vybz.player.data.Song
import com.vybz.player.data.TrackInfo
import com.vybz.player.playback.PlaybackService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Home : Screen
    data object Search : Screen
    data object Sound : Screen
    data object Settings : Screen
    data object About : Screen
    data class Doc(val kind: DocKind) : Screen
    data class Collection(
        val title: String,
        val subtitle: String,
        val songs: List<Song>,
        val artistName: String? = null,
    ) : Screen
}

enum class DocKind(val title: String) {
    PRIVACY("Privacy policy"),
    TERMS("Terms of use"),
    FAQ("FAQ"),
    CHECKLIST("Release checklist"),
}

data class PlayerUi(
    val song: Song? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<Song> = emptyList(),
    val index: Int = 0,
    val buffering: Boolean = false,
    val liveTitle: String? = null,
)

data class NowPlayingExtras(
    val songKey: String = "",
    val artwork: Bitmap? = null,
    val lyricsLoading: Boolean = false,
    val lyrics: Lyrics? = null,
    val info: TrackInfo? = null,
    val artist: ArtistInfo? = null,
)

enum class SortMode(val label: String) { TITLE("Title"), ARTIST("Artist"), ALBUM("Album"), RECENT("Recently added"), DURATION("Duration") }

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx get() = getApplication<Application>()

    private val _library = MutableStateFlow(Library())
    val library: StateFlow<Library> = _library.asStateFlow()
    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _player = MutableStateFlow(PlayerUi())
    val player: StateFlow<PlayerUi> = _player.asStateFlow()

    private val _extras = MutableStateFlow(NowPlayingExtras())
    val extras: StateFlow<NowPlayingExtras> = _extras.asStateFlow()

    // Navigation
    val backStack = mutableStateListOf<Screen>(Screen.Home)
    var nowPlayingOpen by mutableStateOf(false)

    /** Live TV channel currently open in the video player (null = closed). */
    var tvChannel by mutableStateOf<com.vybz.player.data.TvChannel?>(null)
    var inPip by mutableStateOf(false)
    var sortMode by mutableStateOf(SortMode.TITLE)

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var pendingUri: Uri? = null
    private var restored = false
    private var extrasJob: Job? = null

    init {
        connect()
        viewModelScope.launch {
            while (true) {
                delay(400)
                val c = controller ?: continue
                if (c.isPlaying) {
                    _player.value = _player.value.copy(
                        positionMs = c.currentPosition,
                        durationMs = c.duration.coerceAtLeast(0)
                    )
                }
            }
        }
    }

    // ------------------------------------------------------------------ Navigation

    fun navigate(s: Screen) { backStack.add(s) }

    /** @return true if handled */
    fun openTv(channel: com.vybz.player.data.TvChannel) {
        controller?.pause() // music/radio pauses while TV plays
        nowPlayingOpen = false
        tvChannel = channel
    }

    fun closeTv() {
        tvChannel = null
    }

    fun back(): Boolean {
        if (tvChannel != null) { tvChannel = null; return true }
        if (nowPlayingOpen) { nowPlayingOpen = false; return true }
        if (backStack.size > 1) { backStack.removeAt(backStack.lastIndex); return true }
        return false
    }

    // ------------------------------------------------------------------ Library

    private var libraryRequested = false

    /** Loads the library once (e.g. after permission is granted); rescans use [loadLibrary]. */
    fun ensureLibrary() {
        if (libraryRequested) return
        loadLibrary()
    }

    fun loadLibrary() {
        libraryRequested = true
        viewModelScope.launch {
            _loading.value = true
            _library.value = MusicRepository.load(ctx, AppSettings.current.minDurationSec)
            _loading.value = false
            refresh()
            tryRestoreQueue()
        }
    }

    fun sortedSongs(songs: List<Song>): List<Song> = when (sortMode) {
        SortMode.TITLE -> songs.sortedBy { it.title.lowercase() }
        SortMode.ARTIST -> songs.sortedWith(compareBy<Song> { it.artist.lowercase() }.thenBy { it.title.lowercase() })
        SortMode.ALBUM -> songs.sortedWith(compareBy<Song> { it.album.lowercase() }.thenBy { it.track })
        SortMode.RECENT -> songs.sortedByDescending { it.dateAdded }
        SortMode.DURATION -> songs.sortedByDescending { it.duration }
    }

    // ------------------------------------------------------------------ Player connection

    private fun connect() {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        controllerFuture = future
        future.addListener({
            val c = try { future.get() } catch (e: Exception) { null } ?: return@addListener
            controller = c
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = refresh()

                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    android.widget.Toast.makeText(
                        ctx, "Can't play this. Check your connection or try another station/song.", android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            })
            refresh()
            pendingUri?.let { playUri(it); pendingUri = null }
            tryRestoreQueue()
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun songFor(item: MediaItem): Song {
        _library.value.byKey[item.mediaId]?.let { return it }
        if (item.mediaId.startsWith("radio:")) {
            com.vybz.player.data.RadioRepository.stationFor(item.mediaId)?.let { return it.toSong() }
            val u = item.requestMetadata.mediaUri ?: Uri.parse("about:blank")
            return com.vybz.player.data.RadioStation(
                uuid = item.mediaId.removePrefix("radio:"),
                name = item.mediaMetadata.artist?.toString()?.takeIf { it.isNotBlank() } ?: "Radio",
                url = u.toString(),
            ).toSong()
        }
        val uri = item.requestMetadata.mediaUri ?: item.localConfiguration?.uri ?: Uri.parse(item.mediaId)
        return Song.external(uri, item.mediaMetadata.title?.toString())
    }

    private fun refresh() {
        val c = controller ?: return
        val queue = (0 until c.mediaItemCount).map { songFor(c.getMediaItemAt(it)) }
        val idx = c.currentMediaItemIndex
        val song = queue.getOrNull(idx)
        val old = _player.value.song
        _player.value = PlayerUi(
            song = song,
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition,
            durationMs = c.duration.coerceAtLeast(0).let { if (it == 0L) song?.duration ?: 0L else it },
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            queue = queue,
            index = idx,
            buffering = c.playbackState == Player.STATE_BUFFERING,
            // For radio, ICY/HLS metadata replaces the title with the song on air.
            liveTitle = if (song?.isRadio == true) {
                c.mediaMetadata.title?.toString()?.takeIf { it.isNotBlank() && it != song?.title }
            } else null,
        )
        if (song != null && song.key != old?.key) onSongChanged(song)
        if (song == null && old != null) _extras.value = NowPlayingExtras()
    }

    private fun tryRestoreQueue() {
        val c = controller ?: return
        if (restored || _loading.value) return
        restored = true
        if (c.mediaItemCount > 0) return
        val (ids, index, pos) = AppSettings.loadQueue()
        val lib = _library.value.byKey
        val songs = ids.mapNotNull { lib[it] }
        if (songs.isEmpty()) return
        val i = index.coerceIn(0, songs.lastIndex)
        c.setMediaItems(songs.map { it.toMediaItem() }, i, pos)
        c.prepare()
    }

    // ------------------------------------------------------------------ Now playing extras

    private fun onSongChanged(song: Song) {
        extrasJob?.cancel()
        _extras.value = NowPlayingExtras(songKey = song.key, artwork = ArtworkLoader.cached(song, 720))
        extrasJob = viewModelScope.launch {
            val art = ArtworkLoader.load(ctx, song, 720)
            update(song) { it.copy(artwork = art) }
            if (song.isRadio) return@launch // no lyrics / track lookups for live radio
            val s = AppSettings.current
            if (s.autoLyrics) loadLyrics(song, force = false)
            val info = OnlineRepository.trackInfo(ctx, song)
            update(song) { it.copy(info = info) }
            if (art == null && s.autoArtwork && OnlineRepository.fetchArtwork(ctx, song)) {
                ArtworkLoader.invalidate(song)
                val online = ArtworkLoader.load(ctx, song, 720)
                update(song) { it.copy(artwork = online) }
            }
        }
    }

    private inline fun update(song: Song, f: (NowPlayingExtras) -> NowPlayingExtras) {
        val cur = _extras.value
        if (cur.songKey == song.key) _extras.value = f(cur)
    }

    fun loadLyrics(song: Song? = _player.value.song, force: Boolean = false, title: String? = null, artist: String? = null) {
        song ?: return
        viewModelScope.launch {
            update(song) { it.copy(lyricsLoading = true) }
            val l = OnlineRepository.lyrics(ctx, song, force, title, artist)
            update(song) { it.copy(lyrics = l, lyricsLoading = false) }
        }
    }

    fun loadArtistInfo() {
        val song = _player.value.song ?: return
        if (song.isRadio || _extras.value.artist != null) return
        viewModelScope.launch {
            val a = OnlineRepository.artistInfo(ctx, song.artist)
            update(song) { it.copy(artist = a) }
        }
    }

    // ------------------------------------------------------------------ Controls

    fun playSongs(songs: List<Song>, start: Int = 0, shuffle: Boolean = false) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        c.shuffleModeEnabled = shuffle
        val startIndex = if (shuffle) songs.indices.random() else start.coerceIn(0, songs.lastIndex)
        c.setMediaItems(songs.map { it.toMediaItem() }, startIndex, 0L)
        c.prepare()
        c.play()
    }

    /** Plays a list of radio stations, starting at [index]; next/previous move between them. */
    fun playStations(stations: List<com.vybz.player.data.RadioStation>, index: Int) {
        val c = controller ?: return
        if (stations.isEmpty()) return
        c.shuffleModeEnabled = false
        c.repeatMode = Player.REPEAT_MODE_ALL
        c.setMediaItems(stations.map { it.toSong().toMediaItem() }, index.coerceIn(0, stations.lastIndex), 0L)
        c.prepare()
        c.play()
    }

    fun playUri(uri: Uri) {
        val c = controller
        if (c == null) { pendingUri = uri; return }
        val song = Song.external(uri, null)
        c.setMediaItem(song.toMediaItem())
        c.prepare()
        c.play()
        nowPlayingOpen = true
    }

    fun playPause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(c.currentMediaItemIndex, 0)
            c.play()
        }
    }

    fun next() { controller?.seekToNextMediaItem() }

    fun previous() {
        val c = controller ?: return
        val radio = _player.value.song?.isRadio == true
        if (radio) { c.seekToPreviousMediaItem(); return }
        if (c.currentPosition > 3000 || !c.hasPreviousMediaItem()) c.seekTo(0) else c.seekToPreviousMediaItem()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        _player.value = _player.value.copy(positionMs = ms)
    }

    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun playQueueIndex(i: Int) {
        controller?.let { it.seekTo(i, 0L); it.play() }
    }

    fun removeFromQueue(i: Int) { controller?.removeMediaItem(i) }

    fun moveInQueue(from: Int, to: Int) { controller?.moveMediaItem(from, to) }

    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) { playSongs(listOf(song)); return }
        c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) { playSongs(listOf(song)); return }
        c.addMediaItem(song.toMediaItem())
    }

    override fun onCleared() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onCleared()
    }
}
