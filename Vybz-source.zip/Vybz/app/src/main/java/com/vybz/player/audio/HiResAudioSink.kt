package com.vybz.player.audio

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import com.vybz.player.data.AppSettings
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/**
 * Vybz Hi-Res engine. Sits in front of ExoPlayer's audio output and, fully offline:
 *
 *  1. reads the decoder output (16/24/32-bit or float) into 64-bit floating point,
 *  2. runs the Vybz tone chain (EQ etc.),
 *  3. converts the sample rate with a precision sinc resampler to the best rate for the
 *     connected output (device native, or up to 192 kHz on capable USB DACs),
 *  4. optionally applies Hi-Res Restore to compressed files,
 *  5. limits peaks and outputs 32-bit float PCM — no 16-bit truncation anywhere.
 *
 * The wrapped sink must be built with float output enabled.
 */
@UnstableApi
class HiResAudioSink(private val context: Context, sink: AudioSink) : ForwardingAudioSink(sink) {

    private var active = false
    private var inEncoding = C.ENCODING_PCM_16BIT
    private var channels = 2
    private var inRate = 44100
    private var outRate = 44100

    private val core = DspCore()
    private val limiter = PeakLimiter()
    private val exciter = Exciter()
    private var resampler: Resampler? = null

    private var planar = Array(2) { DoubleArray(4096) }
    private val frame = DoubleArray(Biquad.MAX_CHANNELS)

    private var pendingSource: ByteBuffer? = null
    private var pendingOut: ByteBuffer? = null
    private var outBuffer: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())

    override fun configure(inputFormat: Format, specifiedBufferSize: Int, outputChannels: IntArray?) {
        val enc = inputFormat.pcmEncoding
        val supported = MimeTypes.AUDIO_RAW == inputFormat.sampleMimeType &&
            (enc == C.ENCODING_PCM_16BIT || enc == C.ENCODING_PCM_24BIT ||
                enc == C.ENCODING_PCM_32BIT || enc == C.ENCODING_PCM_FLOAT) &&
            inputFormat.channelCount in 1..Biquad.MAX_CHANNELS &&
            inputFormat.sampleRate > 0 &&
            outputChannels == null

        pendingSource = null
        pendingOut = null
        if (!supported) {
            active = false
            AudioEngine.setHqStatus(null)
            super.configure(inputFormat, specifiedBufferSize, outputChannels)
            return
        }

        val s = AppSettings.current
        active = true
        inEncoding = enc
        channels = inputFormat.channelCount
        inRate = inputFormat.sampleRate
        outRate = if (s.hqEnabled) HiResOutput.targetRate(context, inRate, s.hqRate) else inRate

        core.configure(inRate, channels)
        limiter.configure(outRate)
        exciter.configure(outRate)
        resampler = if (outRate != inRate) Resampler(channels, inRate, outRate) else null
        if (planar.size != channels) planar = Array(channels) { DoubleArray(4096) }

        val ratio = outRate.toDouble() / inRate
        val outFormat = inputFormat.buildUpon()
            .setPcmEncoding(C.ENCODING_PCM_FLOAT)
            .setSampleRate(outRate)
            .setEncoderDelay((inputFormat.encoderDelay * ratio).roundToInt())
            .setEncoderPadding((inputFormat.encoderPadding * ratio).roundToInt())
            .build()
        super.configure(outFormat, 0, null)

        AudioEngine.setHqStatus(
            HqStatus(
                sourceBits = when (enc) {
                    C.ENCODING_PCM_16BIT -> "16-bit"
                    C.ENCODING_PCM_24BIT -> "24-bit"
                    C.ENCODING_PCM_32BIT -> "32-bit"
                    else -> "32-bit float"
                },
                sourceRate = inRate,
                outputRate = outRate,
                upscaled = s.hqEnabled,
            )
        )
    }

    override fun handleBuffer(buffer: ByteBuffer, presentationTimeUs: Long, encodedAccessUnitCount: Int): Boolean {
        if (!active) return super.handleBuffer(buffer, presentationTimeUs, encodedAccessUnitCount)
        var out = pendingOut
        if (out == null || pendingSource !== buffer) {
            out = convert(buffer)
            pendingOut = out
            pendingSource = buffer
        }
        val done = super.handleBuffer(out, presentationTimeUs, encodedAccessUnitCount)
        if (done) {
            buffer.position(buffer.limit())
            pendingOut = null
            pendingSource = null
        }
        return done
    }

    override fun flush() {
        pendingOut = null
        pendingSource = null
        core.reset(); limiter.reset(); exciter.reset(); resampler?.reset()
        super.flush()
    }

    override fun reset() {
        pendingOut = null
        pendingSource = null
        super.reset()
    }

    private fun bytesPerSample(): Int = when (inEncoding) {
        C.ENCODING_PCM_16BIT -> 2
        C.ENCODING_PCM_24BIT -> 3
        else -> 4
    }

    /** Converts one decoder buffer into processed 32-bit float PCM at [outRate]. */
    private fun convert(buffer: ByteBuffer): ByteBuffer {
        val src = buffer.duplicate().order(ByteOrder.nativeOrder())
        val ch = channels
        val frames = src.remaining() / (bytesPerSample() * ch)
        if (planar[0].size < frames) planar = Array(ch) { DoubleArray(frames + 1024) }

        // 1) decode to double + 2) tone chain
        core.sync()
        val dsp = core.enabled
        for (f in 0 until frames) {
            for (c in 0 until ch) frame[c] = readSample(src)
            if (dsp) core.process(frame)
            for (c in 0 until ch) planar[c][f] = frame[c]
        }

        // 3) sample-rate conversion
        val r = resampler
        val data: Array<DoubleArray>
        val outFrames: Int
        if (r != null) {
            outFrames = r.process(planar, frames)
            data = r.out
        } else {
            outFrames = frames
            data = planar
        }

        // 4) restore + 5) limiter → float
        val s = AppSettings.current
        val restore = when (s.restoreMode) {
            RESTORE_ALWAYS -> s.restoreAmount.toDouble()
            RESTORE_AUTO -> if (AudioEngine.sourceLossy) s.restoreAmount.toDouble() else 0.0
            else -> 0.0
        }
        val limit = !dsp || core.limiterOn

        val needed = outFrames * ch * 4
        if (outBuffer.capacity() < needed) {
            outBuffer = ByteBuffer.allocateDirect(needed + 16384).order(ByteOrder.nativeOrder())
        }
        val out = outBuffer
        out.clear()
        for (f in 0 until outFrames) {
            for (c in 0 until ch) {
                var v = data[c][f]
                if (restore > 0.0) v = exciter.process(v, c, restore)
                frame[c] = v
            }
            if (limit) limiter.process(frame, ch)
            for (c in 0 until ch) out.putFloat(frame[c].coerceIn(-1.0, 1.0).toFloat())
        }
        out.flip()
        return out
    }

    private fun readSample(b: ByteBuffer): Double = when (inEncoding) {
        C.ENCODING_PCM_16BIT -> b.getShort() / 32768.0
        C.ENCODING_PCM_24BIT -> {
            val b0 = b.get().toInt() and 0xFF
            val b1 = b.get().toInt() and 0xFF
            val b2 = b.get().toInt() // signed top byte
            ((b2 shl 16) or (b1 shl 8) or b0) / 8388608.0
        }
        C.ENCODING_PCM_32BIT -> b.getInt() / 2147483648.0
        else -> b.getFloat().toDouble()
    }

    companion object {
        const val RESTORE_OFF = 0
        const val RESTORE_AUTO = 1
        const val RESTORE_ALWAYS = 2
    }
}
