package com.vybz.player.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Second-order IIR filter (RBJ Audio-EQ-Cookbook), processed in double precision
 * using Transposed Direct Form II for low noise and good numerical stability.
 */
class Biquad {
    var b0 = 1.0; private set
    var b1 = 0.0; private set
    var b2 = 0.0; private set
    var a1 = 0.0; private set
    var a2 = 0.0; private set

    private val z1 = DoubleArray(MAX_CHANNELS)
    private val z2 = DoubleArray(MAX_CHANNELS)

    fun process(x: Double, ch: Int): Double {
        val y = b0 * x + z1[ch]
        z1[ch] = b1 * x - a1 * y + z2[ch]
        z2[ch] = b2 * x - a2 * y
        return y
    }

    fun reset() {
        z1.fill(0.0)
        z2.fill(0.0)
    }

    private fun set(nb0: Double, nb1: Double, nb2: Double, na0: Double, na1: Double, na2: Double) {
        b0 = nb0 / na0; b1 = nb1 / na0; b2 = nb2 / na0
        a1 = na1 / na0; a2 = na2 / na0
    }

    fun setBypass() = set(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)

    fun setPeaking(fs: Double, f0: Double, q: Double, gainDb: Double) {
        val a = Math.pow(10.0, gainDb / 40.0)
        val w0 = 2.0 * PI * safeFreq(f0, fs) / fs
        val alpha = sin(w0) / (2.0 * q)
        val c = cos(w0)
        set(1 + alpha * a, -2 * c, 1 - alpha * a, 1 + alpha / a, -2 * c, 1 - alpha / a)
    }

    fun setLowShelf(fs: Double, f0: Double, q: Double, gainDb: Double) {
        val a = Math.pow(10.0, gainDb / 40.0)
        val w0 = 2.0 * PI * safeFreq(f0, fs) / fs
        val alpha = sin(w0) / (2.0 * q)
        val c = cos(w0)
        val sa = 2.0 * sqrt(a) * alpha
        set(
            a * ((a + 1) - (a - 1) * c + sa),
            2 * a * ((a - 1) - (a + 1) * c),
            a * ((a + 1) - (a - 1) * c - sa),
            (a + 1) + (a - 1) * c + sa,
            -2 * ((a - 1) + (a + 1) * c),
            (a + 1) + (a - 1) * c - sa
        )
    }

    fun setHighShelf(fs: Double, f0: Double, q: Double, gainDb: Double) {
        val a = Math.pow(10.0, gainDb / 40.0)
        val w0 = 2.0 * PI * safeFreq(f0, fs) / fs
        val alpha = sin(w0) / (2.0 * q)
        val c = cos(w0)
        val sa = 2.0 * sqrt(a) * alpha
        set(
            a * ((a + 1) + (a - 1) * c + sa),
            -2 * a * ((a - 1) + (a + 1) * c),
            a * ((a + 1) + (a - 1) * c - sa),
            (a + 1) - (a - 1) * c + sa,
            2 * ((a - 1) - (a + 1) * c),
            (a + 1) - (a - 1) * c - sa
        )
    }

    fun setLowPass(fs: Double, f0: Double, q: Double) {
        val w0 = 2.0 * PI * safeFreq(f0, fs) / fs
        val alpha = sin(w0) / (2.0 * q)
        val c = cos(w0)
        set((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + alpha, -2 * c, 1 - alpha)
    }

    fun setHighPass(fs: Double, f0: Double, q: Double) {
        val w0 = 2.0 * PI * safeFreq(f0, fs) / fs
        val alpha = sin(w0) / (2.0 * q)
        val c = cos(w0)
        set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + alpha, -2 * c, 1 - alpha)
    }

    /** Magnitude response in dB at [freq] — used to draw the EQ curve in the UI. */
    fun magnitudeDb(freq: Double, fs: Double): Double {
        val w = 2.0 * PI * freq / fs
        val cw = cos(w); val sw = sin(w)
        val c2w = cos(2 * w); val s2w = sin(2 * w)
        val nr = b0 + b1 * cw + b2 * c2w
        val ni = -(b1 * sw + b2 * s2w)
        val dr = 1 + a1 * cw + a2 * c2w
        val di = -(a1 * sw + a2 * s2w)
        val mag = sqrt((nr * nr + ni * ni) / (dr * dr + di * di))
        return 20.0 * log10(mag.coerceAtLeast(1e-9))
    }

    private fun safeFreq(f: Double, fs: Double) = f.coerceIn(10.0, fs * 0.45)

    companion object {
        const val MAX_CHANNELS = 8
    }
}
