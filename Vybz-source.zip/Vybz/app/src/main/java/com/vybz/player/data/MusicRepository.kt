package com.vybz.player.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class Song(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val duration: Long,
    val track: Int,
    val year: Int,
    val path: String,
    val folder: String,
    val size: Long,
    val mime: String,
    val dateAdded: Long,
    /** Set for live radio stations (Radio Browser station UUID or a custom id). */
    val radioId: String? = null,
    val radioHls: Boolean = false,
    val favicon: String = "",
) {
    val isRadio: Boolean get() = radioId != null

    val albumArtUri: Uri
        get() = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)

    val key: String
        get() = when {
            radioId != null -> "radio:$radioId"
            id >= 0 -> id.toString()
            else -> uri.toString()
        }

    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(key)
        .setUri(uri)
        .setRequestMetadata(
            MediaItem.RequestMetadata.Builder()
                .setMediaUri(uri)
                .setExtras(android.os.Bundle().apply { putBoolean("hls", radioHls) })
                .build()
        )
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(
                    when {
                        isRadio && favicon.startsWith("http") -> Uri.parse(favicon)
                        albumId > 0 -> albumArtUri
                        else -> null
                    }
                )
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .build()
        )
        .build()

    companion object {
        /** A song opened from another app ("Open with Vybz"). */
        fun external(uri: Uri, title: String?): Song = Song(
            id = -1, uri = uri, title = title ?: uri.lastPathSegment ?: "Audio",
            artist = "Unknown artist", album = "", albumId = -1, duration = 0, track = 0, year = 0,
            path = "", folder = "", size = 0, mime = "", dateAdded = 0
        )
    }
}

data class Album(val id: Long, val title: String, val artist: String, val year: Int, val songs: List<Song>)
data class Artist(val name: String, val songs: List<Song>) {
    val albumCount: Int get() = songs.map { it.albumId }.distinct().size
}
data class Folder(val name: String, val path: String, val songs: List<Song>)

data class Library(
    val songs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val folders: List<Folder> = emptyList(),
) {
    val byKey: Map<String, Song> by lazy { songs.associateBy { it.key } }
}

object MusicRepository {

    suspend fun load(context: Context, minDurationSec: Int): Library = withContext(Dispatchers.IO) {
        val songs = query(context, minDurationSec)
        val albums = songs.groupBy { it.albumId }.map { (id, list) ->
            val sorted = list.sortedWith(compareBy<Song> { it.track }.thenBy { it.title.lowercase() })
            Album(id, list.first().album, mostCommon(list.map { it.artist }), list.maxOf { it.year }, sorted)
        }.sortedBy { it.title.lowercase() }
        val artists = songs.groupBy { primaryArtist(it.artist) }.map { (name, list) ->
            Artist(name, list.sortedWith(compareBy<Song> { it.album.lowercase() }.thenBy { it.track }))
        }.sortedBy { it.name.lowercase() }
        val folders = songs.groupBy { File(it.path).parent ?: "" }.map { (path, list) ->
            Folder(File(path).name.ifBlank { "Music" }, path, list.sortedBy { it.title.lowercase() })
        }.sortedBy { it.name.lowercase() }
        Library(songs, albums, artists, folders)
    }

    @Suppress("DEPRECATION")
    private fun query(context: Context, minDurationSec: Int): List<Song> {
        val collection: Uri = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATE_ADDED,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val args = arrayOf((minDurationSec * 1000L).toString())
        val result = ArrayList<Song>()
        try {
            context.contentResolver.query(
                collection, projection, selection, args,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val iYear = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
                val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val path = c.getString(iData) ?: ""
                    val rawTitle = c.getString(iTitle)
                    val title = if (rawTitle.isNullOrBlank()) File(path).nameWithoutExtension else rawTitle
                    result += Song(
                        id = id,
                        uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                        title = title,
                        artist = cleanUnknown(c.getString(iArtist), "Unknown artist"),
                        album = cleanUnknown(c.getString(iAlbum), "Unknown album"),
                        albumId = c.getLong(iAlbumId),
                        duration = c.getLong(iDur),
                        track = c.getInt(iTrack) % 1000,
                        year = c.getInt(iYear),
                        path = path,
                        folder = File(path).parentFile?.name ?: "",
                        size = c.getLong(iSize),
                        mime = c.getString(iMime) ?: "",
                        dateAdded = c.getLong(iAdded),
                    )
                }
            }
        } catch (e: Exception) {
            // Permission revoked or provider error → empty library rather than a crash.
        }
        return result
    }

    private fun cleanUnknown(v: String?, fallback: String): String =
        if (v.isNullOrBlank() || v == "<unknown>") fallback else v

    private fun mostCommon(list: List<String>): String =
        list.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""

    /** "Sauti Sol feat. Nviiri" → "Sauti Sol" so artists group cleanly. */
    fun primaryArtist(artist: String): String {
        val separators = listOf(" feat. ", " ft. ", " feat ", " ft ", " x ", "; ")
        var a = artist
        for (s in separators) {
            val i = a.indexOf(s, ignoreCase = true)
            if (i > 0) a = a.substring(0, i)
        }
        return a.trim().ifBlank { artist }
    }
}
