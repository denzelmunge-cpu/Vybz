@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vybz.player.ui.screens

import android.content.Context
import android.net.ConnectivityManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vybz.player.data.AppSettings
import com.vybz.player.data.TvChannel
import com.vybz.player.data.TvRegion
import com.vybz.player.data.TvRepository
import com.vybz.player.ui.MainViewModel

private const val FILTER_ALL = "All"
private const val FILTER_FAV = "Favourites"

fun isOnMeteredNetwork(context: Context): Boolean = try {
    (context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
} catch (e: Exception) {
    false
}

@Composable
fun TvTab(vm: MainViewModel) {
    val context = LocalContext.current
    val custom by TvRepository.custom.collectAsState()
    val favs by TvRepository.favourites.collectAsState()
    val settings by AppSettings.state.collectAsState()
    var filter by rememberSaveable { mutableStateOf(FILTER_ALL) }
    var query by rememberSaveable { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var confirmData by remember { mutableStateOf<TvChannel?>(null) }

    val all = remember(custom) { TvRepository.all() }
    val shown = all.filter { ch ->
        val f = when (filter) {
            FILTER_ALL -> true
            FILTER_FAV -> ch.id in favs
            else -> ch.region.label == filter
        }
        f && (query.isBlank() || ch.name.contains(query.trim(), true) || ch.country.contains(query.trim(), true) ||
            ch.category.contains(query.trim(), true))
    }

    fun open(ch: TvChannel) {
        if (ch.playsInApp) {
            if (settings.tvWifiOnly && isOnMeteredNetwork(context)) confirmData = ch else vm.openTv(ch)
        } else {
            ch.externalUrl?.let { openUrl(context, it) }
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search channels") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "Clear search") }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (listOf(FILTER_ALL, FILTER_FAV) + TvRegion.values().map { it.label }).forEach { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f) })
                }
            }
            Text(
                "Free, official live streams only. ▶ Vybz plays inside the app · YouTube opens the broadcaster's " +
                    "official live stream in YouTube. Live TV uses about 0.3–1.5 GB per hour.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
        items(shown, key = { it.id }) { ch ->
            ChannelRow(
                ch,
                isFav = ch.id in favs,
                onClick = { open(ch) },
                onFav = { TvRepository.toggleFavourite(ch.id) },
                onDelete = if (ch.region == TvRegion.MY) ({ TvRepository.removeCustom(ch.id) }) else null,
            )
        }
        if (shown.isEmpty()) {
            item {
                Text(
                    if (filter == FILTER_FAV) "No favourite channels yet. Tap the heart on a channel to keep it here."
                    else "No channels match.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp)
                )
            }
        }
        item {
            TextButton(onClick = { showAdd = true }, modifier = Modifier.padding(horizontal = 8.dp)) {
                Icon(Icons.Rounded.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Add a channel by link")
            }
        }
    }

    if (showAdd) AddChannelDialog { showAdd = false }
    confirmData?.let { ch ->
        AlertDialog(
            onDismissRequest = { confirmData = null },
            title = { Text("You're on mobile data") },
            text = { Text("Live TV uses about 0.3–1.5 GB per hour. Watch ${ch.name} anyway? You can change this in Settings → TV.") },
            confirmButton = { TextButton(onClick = { confirmData = null; vm.openTv(ch) }) { Text("Watch") } },
            dismissButton = { TextButton(onClick = { confirmData = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ChannelRow(ch: TvChannel, isFav: Boolean, onClick: () -> Unit, onFav: () -> Unit, onDelete: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Letter badge (no broadcaster logos are bundled)
        Box(
            Modifier.size(50.dp).clip(RoundedCornerShape(12.dp))
                .background(
                    when (ch.region) {
                        TvRegion.KENYA -> Color(0xFF006600)
                        TvRegion.AFRICA -> Color(0xFFB8860B)
                        TvRegion.INTERNATIONAL -> Color(0xFF1E4D8C)
                        TvRegion.MY -> MaterialTheme.colorScheme.primaryContainer
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                ch.name.split(' ').filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1) }.uppercase(),
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(ch.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (ch.playsInApp) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color(0x33FF0000)
                ) {
                    Text(
                        if (ch.playsInApp) "▶ Vybz" else "YouTube",
                        fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        color = if (ch.playsInApp) MaterialTheme.colorScheme.primary else Color(0xFFFF6B6B),
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }
                Spacer(Modifier.width(6.dp))
                Text(
                    listOf(ch.country, ch.category).filter { it.isNotBlank() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (onDelete != null) {
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Remove channel") }
        }
        IconButton(onClick = onFav) {
            Icon(
                if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                if (isFav) "Remove from favourites" else "Add to favourites",
                tint = if (isFav) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun AddChannelDialog(onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val valid = url.trim().let { it.startsWith("http://") || it.startsWith("https://") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a channel") },
        text = {
            Column {
                OutlinedTextField(name, { name = it.take(40) }, label = { Text("Channel name") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    url, { url = it }, label = { Text("Stream or YouTube link") }, singleLine = true,
                    isError = url.isNotBlank() && !valid,
                    supportingText = { Text("Only add streams you're allowed to watch (.m3u8 links play in Vybz).") }
                )
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { TvRepository.addCustom(name.trim(), url.trim()); onDismiss() }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
