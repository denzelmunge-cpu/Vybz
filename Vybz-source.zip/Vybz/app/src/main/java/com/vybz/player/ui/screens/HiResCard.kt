@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vybz.player.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vybz.player.audio.AudioEngine
import com.vybz.player.audio.HiResAudioSink
import com.vybz.player.audio.HiResOutput
import com.vybz.player.data.AppSettings
import kotlin.math.roundToInt

private val RATE_OPTIONS = listOf(
    HiResOutput.RATE_AUTO to "Auto (best)",
    48000 to "48 kHz",
    96000 to "96 kHz",
    192000 to "192 kHz",
    HiResOutput.RATE_ORIGINAL to "Original",
)

private val RESTORE_OPTIONS = listOf(
    HiResAudioSink.RESTORE_OFF to "Off",
    HiResAudioSink.RESTORE_AUTO to "Compressed files",
    HiResAudioSink.RESTORE_ALWAYS to "All files",
)

@Composable
fun HiResCard(modifier: Modifier = Modifier) {
    val s by AppSettings.state.collectAsState()
    val hq by AudioEngine.hq.collectAsState()

    Card(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.HighQuality, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Hi-Res engine", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Offline, on your phone",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = s.hqEnabled, onCheckedChange = { v -> AppSettings.update { it.copy(hqEnabled = v) } })
            }

            // Live conversion status
            val status = hq
            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (status != null) {
                    Column(Modifier.weight(1f)) {
                        Text("Source", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(status.sourceLabel, fontWeight = FontWeight.SemiBold)
                    }
                    Icon(Icons.Rounded.ArrowForward, "converted to", tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Output", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(status.outputLabel, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                    }
                } else {
                    Text(
                        "Play a song to see the live conversion.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text("Output sample rate", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RATE_OPTIONS.forEach { (value, label) ->
                    FilterChip(
                        selected = s.hqRate == value,
                        enabled = s.hqEnabled,
                        onClick = { AppSettings.update { it.copy(hqRate = value) } },
                        label = { Text(label) }
                    )
                }
            }

            Text("Hi-Res Restore", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RESTORE_OPTIONS.forEach { (value, label) ->
                    FilterChip(
                        selected = s.restoreMode == value,
                        onClick = { AppSettings.update { it.copy(restoreMode = value) } },
                        label = { Text(label) }
                    )
                }
            }
            if (s.restoreMode != HiResAudioSink.RESTORE_OFF) {
                Spacer(Modifier.height(4.dp))
                Column(Modifier.padding(horizontal = 0.dp)) {
                    androidx.compose.material3.Slider(
                        value = s.restoreAmount,
                        onValueChange = { v -> AppSettings.update { it.copy(restoreAmount = (v * 20).roundToInt() / 20f) } },
                        valueRange = 0f..1f
                    )
                    Text(
                        "Restore strength ${(s.restoreAmount * 100).roundToInt()}%",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                "How it works: songs are decoded in 32-bit float, processed in 64-bit, then converted with a " +
                    "precision resampler to the best rate for your output (Auto picks your phone's native rate, " +
                    "or the highest rate of a USB DAC — on Android 14+ Vybz also switches the USB output to hi-res). " +
                    "Output is 32-bit float, so nothing is rounded down to 16 bits. Restore adds gentle " +
                    "high-frequency harmonics to MP3/AAC files that lost their top end. No upscaler can bring back " +
                    "detail that was never in the file; this gives your music the cleanest possible path to your ears.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}
