package com.vybz.player.ui.theme

import android.os.Build
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val VybzViolet = Color(0xFF9B7BFF)
val VybzPink = Color(0xFFFF4D9D)
val VybzCyan = Color(0xFF3DDCFF)

private val VybzDark = darkColorScheme(
    primary = VybzViolet,
    onPrimary = Color(0xFF1A0B4A),
    primaryContainer = Color(0xFF3B2A7A),
    onPrimaryContainer = Color(0xFFE6DEFF),
    secondary = VybzPink,
    onSecondary = Color(0xFF3D0020),
    secondaryContainer = Color(0xFF5C1438),
    onSecondaryContainer = Color(0xFFFFD9E4),
    tertiary = VybzCyan,
    background = Color(0xFF0B0B10),
    onBackground = Color(0xFFEDEBF4),
    surface = Color(0xFF0B0B10),
    onSurface = Color(0xFFEDEBF4),
    surfaceVariant = Color(0xFF1E1C27),
    onSurfaceVariant = Color(0xFFC6C2D4),
    surfaceContainer = Color(0xFF15141C),
    surfaceContainerHigh = Color(0xFF1C1A25),
    surfaceContainerHighest = Color(0xFF26232F),
    outline = Color(0xFF4A4658),
)

private fun ColorScheme.pureBlack(): ColorScheme = copy(
    background = Color.Black,
    surface = Color.Black,
    surfaceContainer = Color(0xFF0D0D10),
    surfaceContainerLow = Color(0xFF070709),
    surfaceContainerLowest = Color.Black,
)

private val VybzType = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Black, fontSize = 32.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 21.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp),
)

// ---------------------------------------------------------------- Kenyan Safari theme
// Savanna gold grass, sunset orange, acacia green, Maasai shuka red on warm earth.
val SafariGold = Color(0xFFE8B04B)
val SafariSunset = Color(0xFFE8743B)
val SafariAcacia = Color(0xFF7FA651)
val SafariMaasaiRed = Color(0xFFC8102E)
val KenyaBlack = Color(0xFF000000)
val KenyaGreen = Color(0xFF006600)

private val SafariDark = darkColorScheme(
    primary = SafariGold,
    onPrimary = Color(0xFF2B1A00),
    primaryContainer = Color(0xFF5C3B0B),
    onPrimaryContainer = Color(0xFFFFDDA8),
    secondary = SafariSunset,
    onSecondary = Color(0xFF3A1200),
    secondaryContainer = Color(0xFF6B2A0E),
    onSecondaryContainer = Color(0xFFFFDBCB),
    tertiary = SafariAcacia,
    onTertiary = Color(0xFF132600),
    error = Color(0xFFFF6B6B),
    background = Color(0xFF16100A),
    onBackground = Color(0xFFF3E7D3),
    surface = Color(0xFF16100A),
    onSurface = Color(0xFFF3E7D3),
    surfaceVariant = Color(0xFF2E2216),
    onSurfaceVariant = Color(0xFFD6C3A5),
    surfaceContainer = Color(0xFF1E160E),
    surfaceContainerHigh = Color(0xFF281D12),
    surfaceContainerHighest = Color(0xFF33261A),
    outline = Color(0xFF6E5A42),
)

private fun ColorScheme.safariNight(): ColorScheme = copy(
    background = Color(0xFF0A0704),
    surface = Color(0xFF0A0704),
    surfaceContainer = Color(0xFF130D07),
    surfaceContainerLow = Color(0xFF0E0905),
    surfaceContainerLowest = Color(0xFF0A0704),
)

object ThemeIds {
    const val NEON = 0
    const val SAFARI = 1
}

/** True when the Kenyan Safari theme is active (used for small decorative touches). */
val LocalSafari = staticCompositionLocalOf { false }

@Composable
fun VybzTheme(dynamicColor: Boolean, pureBlack: Boolean, theme: Int = ThemeIds.NEON, content: @Composable () -> Unit) {
    val safari = theme == ThemeIds.SAFARI
    val scheme = if (safari) {
        if (pureBlack) SafariDark.safariNight() else SafariDark
    } else {
        val base = if (dynamicColor && Build.VERSION.SDK_INT >= 31) {
            dynamicDarkColorScheme(LocalContext.current)
        } else VybzDark
        if (pureBlack) base.pureBlack() else base
    }
    CompositionLocalProvider(LocalSafari provides safari) {
        MaterialTheme(colorScheme = scheme, typography = VybzType, content = content)
    }
}

/** Kenyan-flag stripe (black · red · green with white fimbriations) shown under headers in Safari theme. */
@Composable
fun SafariStripe(modifier: Modifier = Modifier) {
    if (!LocalSafari.current) return
    Column(modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(3.dp).background(KenyaBlack))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White))
        Box(Modifier.fillMaxWidth().height(3.dp).background(SafariMaasaiRed))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White))
        Box(Modifier.fillMaxWidth().height(3.dp).background(KenyaGreen))
    }
}
