package com.vybz.player.ui.screens

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.Build
import android.util.Rational
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.video.MediaCodecVideoRenderer
import androidx.media3.ui.PlayerView
import com.vybz.player.audio.HiResAudioSink
import com.vybz.player.data.AppSettings
import com.vybz.player.data.TvChannel
import com.vybz.player.ui.MainViewModel

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Enters picture-in-picture (Android 8+). Returns false if not supported. */
fun enterTvPip(activity: Activity?): Boolean {
    if (activity == null || Build.VERSION.SDK_INT < 26) return false
    return try {
        activity.enterPictureInPictureMode(
            PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
        )
    } catch (e: Exception) {
        false
    }
}

@OptIn(UnstableApi::class)
private fun buildTvPlayer(context: Context): ExoPlayer {
    // Same Vybz sound engine (EQ, per-device tuning, Hi-Res) for TV sound.
    val sink = HiResAudioSink(
        context,
        DefaultAudioSink.Builder(context).setEnableFloatOutput(true).setEnableAudioTrackPlaybackParams(true).build()
    )
    val renderers = RenderersFactory { handler, videoListener, audioListener, _, _ ->
        arrayOf<Renderer>(
            MediaCodecVideoRenderer(context, MediaCodecSelector.DEFAULT, 5000L, handler, videoListener, 50),
            MediaCodecAudioRenderer(context, MediaCodecSelector.DEFAULT, handler, audioListener, sink),
        )
    }
    return ExoPlayer.Builder(context, renderers)
        .setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
            true
        )
        .setHandleAudioBecomingNoisy(true)
        .setWakeMode(C.WAKE_MODE_NETWORK)
        .build()
}

private fun applyQuality(player: ExoPlayer, q: Int) {
    val b = player.trackSelectionParameters.buildUpon()
        .clearVideoSizeConstraints()
        .setMaxVideoBitrate(Int.MAX_VALUE)
        .setForceHighestSupportedBitrate(false)
    when (q) {
        1 -> b.setMaxVideoSizeSd().setMaxVideoBitrate(900_000)   // data saver
        2 -> b.setForceHighestSupportedBitrate(true)                // best picture
    }
    player.trackSelectionParameters = b.build()
}

private val QUALITY_LABELS = listOf("Auto", "Data saver", "Best (HD)")

@OptIn(UnstableApi::class)
@Composable
fun TvPlayerScreen(vm: MainViewModel, channel: TvChannel) {
    val context = LocalContext.current
    val activity = remember { context.findActivity() }
    val settings by AppSettings.state.collectAsState()
    val player = remember { buildTvPlayer(context) }
    var error by remember { mutableStateOf<String?>(null) }
    var buffering by remember { mutableStateOf(true) }
    var retry by remember { mutableIntStateOf(0) }
    var qualityMenu by remember { mutableStateOf(false) }

    LaunchedEffect(channel.id, retry) {
        error = null
        buffering = true
        val url = channel.streamUrl ?: return@LaunchedEffect
        val item = MediaItem.Builder()
            .setUri(url)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(channel.name).setArtist(channel.country).build())
            .apply { if (url.contains(".m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        player.setMediaItem(item)
        player.prepare()
        player.playWhenReady = true
    }
    LaunchedEffect(settings.tvQuality) { applyQuality(player, settings.tvQuality) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING || state == Player.STATE_IDLE && error == null
                if (state == Player.STATE_READY) buffering = false
            }

            override fun onPlayerError(e: PlaybackException) {
                buffering = false
                error = "${channel.name} isn't available right now. The broadcaster may have moved or paused its stream."
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Pause when the app goes to the background (unless playing in picture-in-picture).
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && !vm.inPip) player.pause()
            if (event == Lifecycle.Event.ON_START) player.play()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    this.player = player
                    useController = true
                    keepScreenOn = true
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                }
            },
            update = { it.useController = !vm.inPip },
            modifier = Modifier.fillMaxSize()
        )

        if (buffering && error == null) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
        }

        if (!vm.inPip) {
            // Top bar
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.closeTv() }) { Icon(Icons.Rounded.ArrowBack, "Close TV", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text(channel.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("● LIVE", color = Color(0xFFFF5252), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                        Text(channel.country, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                }
                Box {
                    IconButton(onClick = { qualityMenu = true }) { Icon(Icons.Rounded.HighQuality, "Picture quality", tint = Color.White) }
                    DropdownMenu(expanded = qualityMenu, onDismissRequest = { qualityMenu = false }) {
                        QUALITY_LABELS.forEachIndexed { i, label ->
                            DropdownMenuItem(
                                text = { Text(if (settings.tvQuality == i) "✓  $label" else "     $label") },
                                onClick = { AppSettings.update { it.copy(tvQuality = i) }; qualityMenu = false }
                            )
                        }
                    }
                }
                IconButton(onClick = {
                    activity?.requestedOrientation =
                        if (activity?.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE)
                            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                }) { Icon(Icons.Rounded.ScreenRotation, "Full screen / rotate", tint = Color.White) }
                if (Build.VERSION.SDK_INT >= 26) {
                    IconButton(onClick = { enterTvPip(activity) }) {
                        Icon(Icons.Rounded.PictureInPictureAlt, "Picture in picture", tint = Color.White)
                    }
                }
            }
        }

        error?.let { msg ->
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(msg, color = Color.White)
                Spacer(Modifier.height(12.dp))
                Row {
                    Button(onClick = { retry++ }) { Text("Try again") }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.closeTv() }) { Text("Close") }
                }
            }
        }
    }
}
