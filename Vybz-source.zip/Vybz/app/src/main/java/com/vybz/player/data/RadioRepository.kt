package com.vybz.player.data

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class RadioStation(
    val uuid: String,
    val name: String,
    val url: String,
    val favicon: String = "",
    val tags: String = "",
    val country: String = "",
    val countryCode: String = "",
    val language: String = "",
    val codec: String = "",
    val bitrate: Int = 0,
    val hls: Boolean = false,
    val homepage: String = "",
) {
    val details: String
        get() = listOf(
            country,
            tags.split(',').map { it.trim() }.filter { it.isNotBlank() }.take(2).joinToString(", "),
            listOf(codec, if (bitrate > 0) "$bitrate kbps" else "").filter { it.isNotBlank() }.joinToString(" "),
        ).filter { it.isNotBlank() }.joinToString(" · ")

    fun toSong(): Song = Song(
        id = -2,
        uri = Uri.parse(url),
        title = name,
        artist = "Live radio" + (if (country.isNotBlank()) " · $country" else ""),
        album = details,
        albumId = -1,
        duration = 0,
        track = 0,
        year = 0,
        path = homepage,
        folder = "",
        size = 0,
        mime = "radio",
        dateAdded = 0,
        radioId = uuid,
        radioHls = hls,
        favicon = favicon,
    )

    fun toJson(): JSONObject = JSONObject()
        .put("uuid", uuid).put("name", name).put("url", url).put("favicon", favicon)
        .put("tags", tags).put("country", country).put("countryCode", countryCode)
        .put("language", language).put("codec", codec).put("bitrate", bitrate)
        .put("hls", hls).put("homepage", homepage)

    companion object {
        fun fromJson(o: JSONObject): RadioStation? {
            val uuid = o.optString("uuid")
            val url = o.optString("url")
            if (uuid.isBlank() || url.isBlank()) return null
            return RadioStation(
                uuid, o.optString("name", "Radio"), url, o.optString("favicon"), o.optString("tags"),
                o.optString("country"), o.optString("countryCode"), o.optString("language"),
                o.optString("codec"), o.optInt("bitrate", 0), o.optBoolean("hls", false), o.optString("homepage"),
            )
        }

        /** Parses one station from the Radio Browser API. */
        fun fromApi(o: JSONObject): RadioStation? {
            val uuid = o.optString("stationuuid")
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }
            if (uuid.isBlank() || url.isBlank()) return null
            return RadioStation(
                uuid = uuid,
                name = o.optString("name").trim().ifBlank { "Radio" },
                url = url,
                favicon = o.optString("favicon"),
                tags = o.optString("tags"),
                country = o.optString("country"),
                countryCode = o.optString("countrycode"),
                language = o.optString("language"),
                codec = o.optString("codec"),
                bitrate = o.optInt("bitrate", 0),
                hls = o.optInt("hls", 0) == 1,
                homepage = o.optString("homepage"),
            )
        }
    }
}

data class RadioFilterOption(val label: String, val value: String, val count: Int)

data class RadioFilters(
    val countryCode: String = "KE",
    val countryName: String = "Kenya",
    val language: String = "",
    val tag: String = "",
)

/**
 * Live radio via Radio Browser (radio-browser.info): a free, community-run directory of
 * 50,000+ stations. No account or API key is needed.
 */
object RadioRepository {

    private val servers = listOf("de1", "de2", "fi1", "nl1", "at1").map { "https://$it.api.radio-browser.info" }
    @Volatile private var preferred = 0

    private lateinit var prefs: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _favourites = MutableStateFlow<List<RadioStation>>(emptyList())
    val favourites: StateFlow<List<RadioStation>> = _favourites.asStateFlow()

    private val _filters = MutableStateFlow(RadioFilters())
    val filters: StateFlow<RadioFilters> = _filters.asStateFlow()

    /** Stations seen this session, so the player can show their details. */
    private val known = java.util.concurrent.ConcurrentHashMap<String, RadioStation>()

    private var countriesCache: List<RadioFilterOption>? = null
    private var languagesCache: List<RadioFilterOption>? = null
    private var tagsCache: List<RadioFilterOption>? = null

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.getSharedPreferences("vybz_radio", Context.MODE_PRIVATE)
        val list = mutableListOf<RadioStation>()
        try {
            val arr = JSONArray(prefs.getString("favourites", "[]"))
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { RadioStation.fromJson(it) }?.let { list += it }
        } catch (e: Exception) { }
        _favourites.value = list
        list.forEach { known[it.uuid] = it }
        _filters.value = RadioFilters(
            countryCode = prefs.getString("f_cc", "KE") ?: "KE",
            countryName = prefs.getString("f_cn", "Kenya") ?: "Kenya",
            language = prefs.getString("f_lang", "") ?: "",
            tag = prefs.getString("f_tag", "") ?: "",
        )
    }

    // ------------------------------------------------------------------ Favourites

    fun isFavourite(uuid: String): Boolean = _favourites.value.any { it.uuid == uuid }

    fun toggleFavourite(station: RadioStation) {
        val cur = _favourites.value
        _favourites.value = if (cur.any { it.uuid == station.uuid }) cur.filterNot { it.uuid == station.uuid } else cur + station
        known[station.uuid] = station
        saveFavourites()
    }

    fun addCustom(name: String, url: String): RadioStation {
        val station = RadioStation(
            uuid = "custom-" + System.currentTimeMillis(),
            name = name.ifBlank { "My station" },
            url = url.trim(),
            hls = url.contains(".m3u8", ignoreCase = true),
            tags = "custom link",
        )
        _favourites.value = _favourites.value + station
        known[station.uuid] = station
        saveFavourites()
        return station
    }

    private fun saveFavourites() {
        if (!::prefs.isInitialized) return
        val arr = JSONArray()
        _favourites.value.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("favourites", arr.toString()).apply()
    }

    fun setFilters(f: RadioFilters) {
        _filters.value = f
        if (::prefs.isInitialized) {
            prefs.edit().putString("f_cc", f.countryCode).putString("f_cn", f.countryName)
                .putString("f_lang", f.language).putString("f_tag", f.tag).apply()
        }
    }

    fun stationFor(key: String): RadioStation? = known[key.removePrefix("radio:")]

    // ------------------------------------------------------------------ Directory

    suspend fun search(query: String, f: RadioFilters, offset: Int, limit: Int = 40): List<RadioStation>? =
        withContext(Dispatchers.IO) {
            val q = buildString {
                append("/json/stations/search?hidebroken=true&order=clickcount&reverse=true")
                append("&limit=").append(limit).append("&offset=").append(offset)
                if (query.isNotBlank()) append("&name=").append(enc(query.trim()))
                if (f.countryCode.isNotBlank()) append("&countrycode=").append(enc(f.countryCode))
                if (f.language.isNotBlank()) append("&language=").append(enc(f.language))
                if (f.tag.isNotBlank()) append("&tag=").append(enc(f.tag))
            }
            val body = get(q) ?: return@withContext null
            val out = ArrayList<RadioStation>()
            try {
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) {
                    arr.optJSONObject(i)?.let { RadioStation.fromApi(it) }?.let { out += it }
                }
            } catch (e: Exception) {
                return@withContext null
            }
            out.forEach { known[it.uuid] = it }
            out
        }

    suspend fun countries(): List<RadioFilterOption> = countriesCache ?: withContext(Dispatchers.IO) {
        options("/json/countries?order=stationcount&reverse=true&hidebroken=true", "iso_3166_1")
            .also { if (it.isNotEmpty()) countriesCache = it }
    }

    suspend fun languages(): List<RadioFilterOption> = languagesCache ?: withContext(Dispatchers.IO) {
        options("/json/languages?order=stationcount&reverse=true&hidebroken=true&limit=200", null)
            .also { if (it.isNotEmpty()) languagesCache = it }
    }

    suspend fun genres(): List<RadioFilterOption> = tagsCache ?: withContext(Dispatchers.IO) {
        options("/json/tags?order=stationcount&reverse=true&hidebroken=true&limit=250", null)
            .also { if (it.isNotEmpty()) tagsCache = it }
    }

    private fun options(path: String, valueField: String?): List<RadioFilterOption> {
        val body = get(path) ?: return emptyList()
        return try {
            val arr = JSONArray(body)
            val out = ArrayList<RadioFilterOption>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name").trim()
                if (name.isBlank()) continue
                val count = o.optInt("stationcount", 0)
                if (count < 3) continue
                val value = if (valueField != null) o.optString(valueField) else name
                if (value.isBlank()) continue
                out += RadioFilterOption(name.replaceFirstChar { it.uppercase() }, value, count)
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Tells Radio Browser a station was played (helps rank popular stations). */
    fun reportPlay(uuid: String) {
        if (uuid.startsWith("custom-")) return
        scope.launch { get("/json/url/" + enc(uuid)) }
    }

    // ------------------------------------------------------------------ HTTP

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun get(path: String): String? {
        for (attempt in servers.indices) {
            val idx = (preferred + attempt) % servers.size
            val body = fetch(servers[idx] + path)
            if (body != null) {
                preferred = idx
                return body
            }
        }
        return null
    }

    private fun fetch(url: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 7000
            conn.readTimeout = 12000
            conn.setRequestProperty("User-Agent", "Vybz/1.3 (Android music & radio player)")
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode in 200..299) conn.inputStream.bufferedReader().use { it.readText() } else null
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
