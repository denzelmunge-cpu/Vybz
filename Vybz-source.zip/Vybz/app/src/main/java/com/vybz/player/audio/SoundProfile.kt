package com.vybz.player.audio

import org.json.JSONArray
import org.json.JSONObject

/** Centre frequencies of the 10-band graphic EQ (ISO octave bands). */
val EQ_FREQS = doubleArrayOf(31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)
val EQ_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
const val EQ_BAND_Q = 1.41
const val EQ_MAX_DB = 12f

/** Where the sound is currently going. Each output gets its own sound profile. */
enum class OutputType(val label: String) {
    SPEAKER("Phone speaker"),
    WIRED("Wired 3.5mm"),
    USB("USB-C / DAC"),
    BLUETOOTH("Bluetooth"),
}

data class SoundProfile(
    val enabled: Boolean = true,
    val presetName: String = "Flat",
    val bands: List<Float> = List(10) { 0f },
    val preampDb: Float = 0f,
    val bassDb: Float = 0f,
    val trebleDb: Float = 0f,
    val width: Float = 1f,        // 0 = mono, 1 = normal, 2 = extra wide
    val balance: Float = 0f,      // -1 left … +1 right
    val crossfeed: Float = 0f,    // 0 … 1 (headphone crossfeed)
    val mono: Boolean = false,
    val limiter: Boolean = true,
    val autoHeadroom: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("enabled", enabled)
        put("presetName", presetName)
        put("bands", JSONArray().also { arr -> bands.forEach { arr.put(it.toDouble()) } })
        put("preampDb", preampDb.toDouble())
        put("bassDb", bassDb.toDouble())
        put("trebleDb", trebleDb.toDouble())
        put("width", width.toDouble())
        put("balance", balance.toDouble())
        put("crossfeed", crossfeed.toDouble())
        put("mono", mono)
        put("limiter", limiter)
        put("autoHeadroom", autoHeadroom)
    }

    companion object {
        fun fromJson(o: JSONObject?): SoundProfile {
            if (o == null) return SoundProfile()
            val arr = o.optJSONArray("bands")
            val bands = if (arr != null && arr.length() == 10) {
                List(10) { arr.optDouble(it, 0.0).toFloat() }
            } else List(10) { 0f }
            return SoundProfile(
                enabled = o.optBoolean("enabled", true),
                presetName = o.optString("presetName", "Flat"),
                bands = bands,
                preampDb = o.optDouble("preampDb", 0.0).toFloat(),
                bassDb = o.optDouble("bassDb", 0.0).toFloat(),
                trebleDb = o.optDouble("trebleDb", 0.0).toFloat(),
                width = o.optDouble("width", 1.0).toFloat(),
                balance = o.optDouble("balance", 0.0).toFloat(),
                crossfeed = o.optDouble("crossfeed", 0.0).toFloat(),
                mono = o.optBoolean("mono", false),
                limiter = o.optBoolean("limiter", true),
                autoHeadroom = o.optBoolean("autoHeadroom", true),
            )
        }
    }
}

data class EqPreset(val name: String, val bands: List<Float>, val category: String = "Music")

object Presets {
    private fun p(name: String, vararg v: Int, category: String = "Music") =
        EqPreset(name, v.map { it.toFloat() }, category)

    val music = listOf(
        p("Flat", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        p("Bass Boost", 6, 5, 4, 2, 0, 0, 0, 0, 0, 0),
        p("Deep Bass", 8, 7, 5, 2, -1, 0, 0, 0, 0, 0),
        p("Bass Reducer", -6, -5, -4, -2, 0, 0, 0, 0, 0, 0),
        p("Treble Boost", 0, 0, 0, 0, 0, 1, 2, 4, 5, 6),
        p("Vocal", -2, -2, -1, 1, 3, 4, 3, 1, 0, -1),
        p("Afrobeats", 5, 4, 2, 0, -1, 1, 2, 2, 3, 2),
        p("Hip-Hop", 5, 4, 2, 3, -1, -1, 1, 0, 2, 3),
        p("Electronic", 4, 4, 1, 0, -2, 2, 1, 1, 4, 5),
        p("Rock", 4, 3, 2, 0, -1, -1, 1, 2, 3, 4),
        p("Pop", -1, 1, 3, 4, 3, 1, 0, 0, 1, 2),
        p("Jazz", 3, 2, 1, 2, -1, -1, 0, 1, 2, 3),
        p("Classical", 4, 3, 2, 1, -1, -1, 0, 2, 3, 4),
        p("Acoustic", 4, 3, 2, 1, 2, 2, 3, 3, 2, 1),
        p("Gospel", 3, 2, 1, 1, 2, 3, 2, 1, 1, 1),
        p("Loudness", 6, 4, 0, 0, -2, 0, -1, -3, 4, 2),
        p("Spoken / Podcast", -4, -3, -1, 1, 3, 4, 3, 1, -1, -3),
    )

    /** Starting points that compensate the typical sound signature of common listening gear. */
    val gear = listOf(
        p("Wired EarPods", 5, 4, 3, 1, 0, 0, -1, 1, 2, 1, category = "Gear"),
        p("TWS Earbuds", 2, 1, 0, 0, 0, 0, 1, 2, 1, 0, category = "Gear"),
        p("In-ear (IEM)", 2, 2, 1, 0, 0, 0, 0, -1, 0, 1, category = "Gear"),
        p("Over-ear", 3, 2, 1, 0, 0, 0, 0, 1, 1, 0, category = "Gear"),
        p("Phone Speaker", -6, -4, -1, 1, 2, 2, 1, 1, 0, -1, category = "Gear"),
        p("BT Speaker / Car", 3, 2, 1, 0, 0, 0, 1, 1, 1, 0, category = "Gear"),
    )

    val all = music + gear

    /** Sensible default per output so the app sounds good out of the box. */
    fun defaultFor(type: OutputType): SoundProfile = when (type) {
        OutputType.SPEAKER -> SoundProfile(presetName = "Phone Speaker", bands = gear[4].bands)
        else -> SoundProfile()
    }
}

/** Immutable snapshot read by the audio thread. */
class DspParams(
    val version: Long,
    val enabled: Boolean,
    val bands: FloatArray,
    val preampDb: Float,
    val bassDb: Float,
    val trebleDb: Float,
    val width: Float,
    val balance: Float,
    val crossfeed: Float,
    val mono: Boolean,
    val limiter: Boolean,
) {
    companion object {
        val DEFAULT = from(SoundProfile(enabled = false), 0L)

        fun from(p: SoundProfile, version: Long): DspParams {
            val maxBoost = maxOf(0f, p.bands.maxOrNull() ?: 0f, p.bassDb, p.trebleDb)
            val headroom = if (p.autoHeadroom) maxBoost * 0.6f else 0f
            return DspParams(
                version = version,
                enabled = p.enabled,
                bands = p.bands.toFloatArray(),
                preampDb = p.preampDb - headroom,
                bassDb = p.bassDb,
                trebleDb = p.trebleDb,
                width = p.width,
                balance = p.balance,
                crossfeed = p.crossfeed,
                mono = p.mono,
                limiter = p.limiter,
            )
        }
    }
}
