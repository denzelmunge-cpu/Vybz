package com.vybz.player.data

import android.content.Context
import android.net.ConnectivityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import kotlin.math.abs

data class LyricLine(val timeMs: Long, val text: String)

data class Lyrics(
    val synced: List<LyricLine> = emptyList(),
    val plain: String? = null,
    val source: String = "",
) {
    val isEmpty: Boolean get() = synced.isEmpty() && plain.isNullOrBlank()
}

data class TrackInfo(
    val genre: String = "",
    val year: String = "",
    val album: String = "",
    val artworkUrl: String = "",
    val link: String = "",
)

data class ArtistInfo(
    val name: String,
    val bio: String = "",
    val imageUrl: String = "",
    val link: String = "",
)

/**
 * Offline-first online lookups. Everything fetched is cached on the phone, so lyrics,
 * info and artwork keep working with no data connection once a song has been seen.
 *
 * Sources (free, no account/API key): LRCLIB (lyrics), iTunes Search (artwork, genre,
 * year), Wikipedia (artist bio).
 */
object OnlineRepository {

    private const val UA = "Vybz Music Player/1.0 (Android; offline-first)"

    private fun dir(context: Context, sub: String) =
        File(context.filesDir, "online/$sub").apply { mkdirs() }

    fun songKey(title: String, artist: String): String {
        val raw = (cleanTitle(title) + "|" + MusicRepository.primaryArtist(artist)).lowercase()
        val md = MessageDigest.getInstance("MD5").digest(raw.toByteArray())
        return md.joinToString("") { "%02x".format(it) }
    }

    fun artFile(context: Context, song: Song): File =
        File(dir(context, "art"), songKey(song.title, song.artist) + ".jpg")

    fun cacheSizeBytes(context: Context): Long =
        File(context.filesDir, "online").walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun clearCache(context: Context) {
        File(context.filesDir, "online").deleteRecursively()
    }

    fun networkAllowed(context: Context): Boolean {
        val s = AppSettings.current
        if (!s.consentAsked || !s.onlineEnabled) return false
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        @Suppress("DEPRECATION")
        val connected = cm.activeNetworkInfo?.isConnected == true
        if (!connected) return false
        if (s.wifiOnly && cm.isActiveNetworkMetered) return false
        return true
    }

    // ------------------------------------------------------------------ Lyrics

    suspend fun lyrics(
        context: Context,
        song: Song,
        force: Boolean = false,
        titleOverride: String? = null,
        artistOverride: String? = null,
    ): Lyrics = withContext(Dispatchers.IO) {
        val cache = File(dir(context, "lyrics"), songKey(song.title, song.artist) + ".json")

        if (!force && cache.exists()) {
            readLyricsCache(cache)?.let { return@withContext it }
        }

        // 1) A .lrc file next to the song (works on older Android / when accessible)
        if (!force) {
            localLrc(song)?.let { return@withContext it }
        }

        // 2) LRCLIB online
        if (!networkAllowed(context)) return@withContext Lyrics()
        val title = cleanTitle(titleOverride ?: song.title)
        val artist = MusicRepository.primaryArtist(artistOverride ?: song.artist)
            .takeIf { it != "Unknown artist" } ?: ""
        val hit = searchLrclib(title, artist, song.duration / 1000.0)
        val lyrics = hit?.lyrics ?: Lyrics()
        // Cache result (including "not found" so we don't hit the network every time)
        try {
            cache.writeText(
                JSONObject()
                    .put("synced", hit?.raw ?: "")
                    .put("plain", lyrics.plain ?: "")
                    .put("source", lyrics.source)
                    .toString()
            )
        } catch (e: Exception) { }
        lyrics
    }

    private class LrcHit(val lyrics: Lyrics, val raw: String)

    private fun readLyricsCache(f: File): Lyrics? = try {
        val o = JSONObject(f.readText())
        val synced = o.optString("synced", "")
        Lyrics(LrcParser.parse(synced), o.optString("plain", "").ifBlank { null }, o.optString("source", ""))
    } catch (e: Exception) { null }

    private fun localLrc(song: Song): Lyrics? {
        if (song.path.isBlank()) return null
        return try {
            val f = File(song.path.substringBeforeLast('.') + ".lrc")
            if (f.exists() && f.canRead()) {
                val text = f.readText()
                val lines = LrcParser.parse(text)
                if (lines.isNotEmpty()) Lyrics(lines, null, "Local .lrc file") else Lyrics(emptyList(), text, "Local .lrc file")
            } else null
        } catch (e: Exception) { null }
    }

    private fun searchLrclib(title: String, artist: String, durationSec: Double): LrcHit? {
        if (title.isBlank()) return null
        val urls = mutableListOf<String>()
        if (artist.isNotBlank()) {
            urls += "https://lrclib.net/api/search?track_name=${enc(title)}&artist_name=${enc(artist)}"
        }
        urls += "https://lrclib.net/api/search?q=${enc("$artist $title".trim())}"

        for (url in urls) {
            val body = httpGet(url) ?: continue
            val arr = try { JSONArray(body) } catch (e: Exception) { continue }
            if (arr.length() == 0) continue
            var best: JSONObject? = null
            var bestScore = Double.MAX_VALUE
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val hasSynced = o.optString("syncedLyrics", "").isNotBlank() && !o.isNull("syncedLyrics")
                val hasPlain = o.optString("plainLyrics", "").isNotBlank() && !o.isNull("plainLyrics")
                if (!hasSynced && !hasPlain) continue
                val d = o.optDouble("duration", 0.0)
                var score = if (durationSec > 0 && d > 0) abs(d - durationSec) else 5.0
                if (!hasSynced) score += 4.0
                if (score < bestScore) { bestScore = score; best = o }
            }
            val b = best ?: continue
            if (durationSec > 0 && bestScore > 20) continue // probably a different version
            val synced = if (b.isNull("syncedLyrics")) "" else b.optString("syncedLyrics", "")
            val plain = if (b.isNull("plainLyrics")) "" else b.optString("plainLyrics", "")
            return LrcHit(Lyrics(LrcParser.parse(synced), plain.ifBlank { null }, "LRCLIB"), synced)
        }
        return null
    }

    // ------------------------------------------------------------------ Track info + artwork

    suspend fun trackInfo(context: Context, song: Song, force: Boolean = false): TrackInfo? =
        withContext(Dispatchers.IO) {
            val cache = File(dir(context, "info"), songKey(song.title, song.artist) + ".json")
            if (!force && cache.exists()) {
                try {
                    val o = JSONObject(cache.readText())
                    return@withContext TrackInfo(
                        o.optString("genre"), o.optString("year"), o.optString("album"),
                        o.optString("artworkUrl"), o.optString("link")
                    )
                } catch (e: Exception) { }
            }
            if (!networkAllowed(context)) return@withContext null
            val title = cleanTitle(song.title)
            val artist = MusicRepository.primaryArtist(song.artist).takeIf { it != "Unknown artist" } ?: ""
            val body = httpGet(
                "https://itunes.apple.com/search?term=${enc("$artist $title".trim())}&entity=song&media=music&limit=8"
            ) ?: return@withContext null
            val results = try { JSONObject(body).optJSONArray("results") } catch (e: Exception) { null }
                ?: return@withContext null
            var pick: JSONObject? = null
            for (i in 0 until results.length()) {
                val o = results.optJSONObject(i) ?: continue
                val a = o.optString("artistName")
                if (artist.isBlank() || a.contains(artist, true) || artist.contains(a, true)) { pick = o; break }
            }
            val o = pick ?: return@withContext TrackInfo().also { cache.writeText(JSONObject().toString()) }
            val info = TrackInfo(
                genre = o.optString("primaryGenreName"),
                year = o.optString("releaseDate").take(4),
                album = o.optString("collectionName"),
                artworkUrl = o.optString("artworkUrl100").replace("100x100bb", "600x600bb"),
                link = o.optString("trackViewUrl"),
            )
            try {
                cache.writeText(
                    JSONObject().put("genre", info.genre).put("year", info.year).put("album", info.album)
                        .put("artworkUrl", info.artworkUrl).put("link", info.link).toString()
                )
            } catch (e: Exception) { }
            info
        }

    /** Downloads cover art for songs with no embedded artwork. Returns true if a file is now cached. */
    suspend fun fetchArtwork(context: Context, song: Song): Boolean = withContext(Dispatchers.IO) {
        val f = artFile(context, song)
        if (f.exists() && f.length() > 0) return@withContext true
        val info = trackInfo(context, song) ?: return@withContext false
        if (info.artworkUrl.isBlank() || !networkAllowed(context)) return@withContext false
        val bytes = httpGetBytes(info.artworkUrl) ?: return@withContext false
        try { f.writeBytes(bytes); true } catch (e: Exception) { false }
    }

    // ------------------------------------------------------------------ Artist bio

    suspend fun artistInfo(context: Context, artistName: String): ArtistInfo? = withContext(Dispatchers.IO) {
        val artist = MusicRepository.primaryArtist(artistName)
        if (artist.isBlank() || artist == "Unknown artist") return@withContext null
        val key = songKey("artist", artist)
        val cache = File(dir(context, "artist"), "$key.json")
        if (cache.exists()) {
            try {
                val o = JSONObject(cache.readText())
                return@withContext ArtistInfo(artist, o.optString("bio"), o.optString("image"), o.optString("link"))
            } catch (e: Exception) { }
        }
        if (!networkAllowed(context)) return@withContext null
        val musicWords = listOf("singer", "musician", "band", "rapper", "songwriter", "dj", "producer",
            "group", "artist", "vocalist", "duo", "music", "composer")
        var result: ArtistInfo? = null
        for (candidate in listOf(artist, "$artist (musician)", "$artist (band)", "$artist (singer)")) {
            val body = httpGet(
                "https://en.wikipedia.org/api/rest_v1/page/summary/" + enc(candidate.replace(' ', '_')).replace("+", "%20")
            ) ?: continue
            val o = try { JSONObject(body) } catch (e: Exception) { continue }
            if (o.optString("type") == "disambiguation") continue
            val extract = o.optString("extract")
            if (musicWords.none { extract.contains(it, ignoreCase = true) }) continue
            result = ArtistInfo(
                artist,
                extract,
                o.optJSONObject("thumbnail")?.optString("source") ?: "",
                o.optJSONObject("content_urls")?.optJSONObject("mobile")?.optString("page") ?: "",
            )
            break
        }
        val r = result ?: ArtistInfo(artist)
        try {
            cache.writeText(JSONObject().put("bio", r.bio).put("image", r.imageUrl).put("link", r.link).toString())
        } catch (e: Exception) { }
        r
    }

    // ------------------------------------------------------------------ Helpers

    /** Strips noise like "(Official Video)", "[Lyrics]", "01 - " so lookups match. */
    fun cleanTitle(t: String): String {
        var s = t
        s = s.replace(Regex("^\\s*\\d{1,3}\\s*[-._)]\\s+"), "")
        s = s.replace(
            Regex("\\s*[(\\[][^)\\]]*(official|video|audio|lyric|visuali[sz]er|hd|hq|remaster|explicit|mp3)[^)\\]]*[)\\]]",
                RegexOption.IGNORE_CASE), ""
        )
        s = s.replace(Regex("\\s*[(\\[]?\\s*(feat\\.?|ft\\.?)\\s+[^)\\]]*[)\\]]?", RegexOption.IGNORE_CASE), "")
        s = s.replace('_', ' ').trim()
        return s.ifBlank { t }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun open(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 12000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", UA)
        return conn
    }

    private fun httpGet(url: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = open(url)
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode in 200..299) conn.inputStream.bufferedReader().use { it.readText() } else null
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    fun httpGetBytes(url: String): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            conn = open(url)
            if (conn.responseCode in 200..299) conn.inputStream.use { it.readBytes() } else null
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}

object LrcParser {
    private val timeTag = Regex("\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?]")
    private val offsetTag = Regex("\\[offset:\\s*([+-]?\\d+)\\s*]", RegexOption.IGNORE_CASE)

    fun parse(text: String?): List<LyricLine> {
        if (text.isNullOrBlank()) return emptyList()
        val offset = offsetTag.find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val out = ArrayList<LyricLine>()
        text.lineSequence().forEach { line ->
            val tags = timeTag.findAll(line).toList()
            if (tags.isEmpty()) return@forEach
            val lyric = line.substring(tags.last().range.last + 1).trim()
            for (m in tags) {
                val min = m.groupValues[1].toLongOrNull() ?: 0L
                val sec = m.groupValues[2].toLongOrNull() ?: 0L
                val fracStr = m.groupValues[3]
                val frac = when (fracStr.length) {
                    0 -> 0L
                    1 -> fracStr.toLong() * 100
                    2 -> fracStr.toLong() * 10
                    else -> fracStr.take(3).toLong()
                }
                val t = (min * 60_000 + sec * 1000 + frac - offset).coerceAtLeast(0)
                out += LyricLine(t, lyric)
            }
        }
        return out.sortedBy { it.timeMs }
    }
}
