package com.vybz.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.ui.res.painterResource
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.vybz.player.data.AppSettings
import com.vybz.player.ui.MainViewModel
import com.vybz.player.ui.Screen
import com.vybz.player.ui.components.MiniPlayer
import com.vybz.player.ui.screens.AboutScreen
import com.vybz.player.ui.screens.CollectionScreen
import com.vybz.player.ui.screens.DocScreen
import com.vybz.player.ui.screens.LibraryScreen
import com.vybz.player.ui.screens.NowPlayingScreen
import com.vybz.player.ui.screens.SearchScreen
import com.vybz.player.ui.screens.SettingsScreen
import com.vybz.player.ui.screens.SoundScreen
import com.vybz.player.ui.theme.VybzTheme

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleIntent(intent)
        addOnPictureInPictureModeChangedListener { info -> vm.inPip = info.isInPictureInPictureMode }
        setContent {
            val settings by AppSettings.state.collectAsState()
            VybzTheme(dynamicColor = settings.dynamicColor, pureBlack = settings.pureBlack, theme = settings.theme) {
                Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                    PermissionGate(vm) { VybzRoot(vm) }
                }
            }
        }
    }

    /** Pressing Home while watching TV continues it in a small floating window. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (vm.tvChannel != null) com.vybz.player.ui.screens.enterTvPip(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { vm.playUri(it) }
        }
    }
}

@Composable
private fun PermissionGate(vm: MainViewModel, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    val perms = if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(audioPerm, Manifest.permission.POST_NOTIFICATIONS)
    } else arrayOf(audioPerm)

    fun isGranted() = ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(isGranted()) }
    var asked by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = isGranted()
        asked = true
    }
    LaunchedEffect(granted) { if (granted) vm.ensureLibrary() }

    if (granted) {
        content()
    } else {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painterResource(R.drawable.vybz_logo),
                contentDescription = "Vybz logo",
                modifier = Modifier.fillMaxWidth(0.6f)
            )
            Spacer(Modifier.height(16.dp))
            Text("Welcome to Vybz", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "Vybz needs access to the music on your phone. Everything plays offline — nothing is uploaded.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = { launcher.launch(perms) }) { Text("Allow music access") }
            if (asked) {
                TextButton(onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("Open app settings") }
            }
        }
    }
}

@Composable
private fun VybzRoot(vm: MainViewModel) {
    val player by vm.player.collectAsState()
    val extras by vm.extras.collectAsState()

    BackHandler(enabled = vm.tvChannel != null || vm.nowPlayingOpen || vm.backStack.size > 1) { vm.back() }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (val screen = vm.backStack.last()) {
                    Screen.Home -> LibraryScreen(vm)
                    Screen.Search -> SearchScreen(vm)
                    Screen.Sound -> SoundScreen(vm)
                    Screen.Settings -> SettingsScreen(vm)
                    Screen.About -> AboutScreen(vm)
                    is Screen.Doc -> DocScreen(vm, screen.kind)
                    is Screen.Collection -> CollectionScreen(vm, screen)
                }
            }
            Box(Modifier.navigationBarsPadding()) {
                MiniPlayer(
                    state = player,
                    artwork = extras.artwork,
                    onOpen = { vm.nowPlayingOpen = true },
                    onPlayPause = { vm.playPause() },
                    onNext = { vm.next() },
                )
            }
        }
        AnimatedVisibility(
            visible = vm.nowPlayingOpen && player.song != null,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            NowPlayingScreen(vm)
        }
        // Live TV player sits above everything (and alone in picture-in-picture).
        vm.tvChannel?.let { ch ->
            androidx.compose.runtime.key(ch.id) { com.vybz.player.ui.screens.TvPlayerScreen(vm, ch) }
        }
    }

    // First launch: ask before using the internet (the app's "cookie consent").
    val settings by AppSettings.state.collectAsState()
    if (!settings.consentAsked) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Vybz works offline") },
            text = {
                Text(
                    "Playback, the Hi-Res engine and all sound settings run on your phone with no internet. " +
                        "Optionally, Vybz can look up lyrics, cover art and artist bios online — it sends only " +
                        "song titles and artist names (to LRCLIB, iTunes Search and Wikipedia) and saves the " +
                        "results for offline use. You can change this any time in Settings."
                )
            },
            confirmButton = {
                Button(onClick = { AppSettings.update { it.copy(consentAsked = true, onlineEnabled = false) } }) {
                    Text("Keep it offline")
                }
            },
            dismissButton = {
                TextButton(onClick = { AppSettings.update { it.copy(consentAsked = true, onlineEnabled = true) } }) {
                    Text("Allow lyrics & art lookups")
                }
            },
        )
    }
}
