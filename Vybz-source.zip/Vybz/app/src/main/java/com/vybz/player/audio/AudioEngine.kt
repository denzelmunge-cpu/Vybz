package com.vybz.player.audio

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** What the Hi-Res engine is doing right now (shown in the UI). */
data class HqStatus(
    val sourceBits: String,
    val sourceRate: Int,
    val outputRate: Int,
    val upscaled: Boolean,
) {
    val sourceLabel: String get() = "$sourceBits / ${HiResOutput.describeRate(sourceRate)}"
    val outputLabel: String get() = "32-bit float / ${HiResOutput.describeRate(outputRate)}"
    val shortLabel: String get() = "32f · ${HiResOutput.describeRate(outputRate)}"
}

data class EngineState(
    val perDevice: Boolean = true,
    val global: SoundProfile = SoundProfile(),
    val deviceProfiles: Map<OutputType, SoundProfile> = emptyMap(),
    val output: OutputInfo = OutputInfo(OutputType.SPEAKER, OutputType.SPEAKER.label, ""),
    val customPresets: List<EqPreset> = emptyList(),
) {
    fun profileFor(type: OutputType): SoundProfile =
        deviceProfiles[type] ?: Presets.defaultFor(type)

    /** The profile actually being heard right now. */
    val active: SoundProfile
        get() = if (perDevice) profileFor(output.type) else global
}

/**
 * Single source of truth for sound settings. Shared by the UI and the playback service
 * (same process), and publishes a lock-free snapshot to the DSP on the audio thread.
 */
object AudioEngine {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(EngineState())
    val state: StateFlow<EngineState> = _state.asStateFlow()

    @Volatile
    var dsp: DspParams = DspParams.DEFAULT
        private set

    /** True when the current file uses lossy compression (MP3, AAC, OGG…). Set by the player. */
    @Volatile
    var sourceLossy: Boolean = true

    private val _hq = MutableStateFlow<HqStatus?>(null)
    val hq: StateFlow<HqStatus?> = _hq.asStateFlow()

    fun setHqStatus(status: HqStatus?) {
        _hq.value = status
    }

    private var version = 1L
    private var monitor: OutputMonitor? = null

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.getSharedPreferences("vybz_sound", Context.MODE_PRIVATE)
        _state.value = load()
        publish()
        monitor = OutputMonitor(context.applicationContext) { info ->
            _state.value = _state.value.copy(output = info)
            publish()
        }.also { it.start() }
    }

    /** null target = the profile currently in use. */
    fun update(target: OutputType?, transform: (SoundProfile) -> SoundProfile) {
        val s = _state.value
        _state.value = if (!s.perDevice) {
            s.copy(global = transform(s.global))
        } else {
            val key = target ?: s.output.type
            s.copy(deviceProfiles = s.deviceProfiles + (key to transform(s.profileFor(key))))
        }
        publish(); save()
    }

    fun setPerDevice(on: Boolean) {
        _state.value = _state.value.copy(perDevice = on)
        publish(); save()
    }

    fun saveCustomPreset(name: String, bands: List<Float>) {
        val s = _state.value
        val list = s.customPresets.filterNot { it.name.equals(name, true) } + EqPreset(name, bands, "Custom")
        _state.value = s.copy(customPresets = list)
        save()
    }

    fun deleteCustomPreset(name: String) {
        val s = _state.value
        _state.value = s.copy(customPresets = s.customPresets.filterNot { it.name == name })
        save()
    }

    private fun publish() {
        version++
        dsp = DspParams.from(_state.value.active, version)
    }

    private fun save() {
        val s = _state.value
        val o = JSONObject()
        o.put("perDevice", s.perDevice)
        o.put("global", s.global.toJson())
        val dev = JSONObject()
        s.deviceProfiles.forEach { (k, v) -> dev.put(k.name, v.toJson()) }
        o.put("devices", dev)
        val cp = JSONArray()
        s.customPresets.forEach { p ->
            cp.put(JSONObject().put("name", p.name).put("bands", JSONArray().also { a -> p.bands.forEach { a.put(it.toDouble()) } }))
        }
        o.put("custom", cp)
        prefs.edit().putString("state", o.toString()).apply()
    }

    private fun load(): EngineState {
        val raw = prefs.getString("state", null) ?: return EngineState()
        return try {
            val o = JSONObject(raw)
            val devObj = o.optJSONObject("devices")
            val devices = mutableMapOf<OutputType, SoundProfile>()
            if (devObj != null) {
                OutputType.values().forEach { t ->
                    devObj.optJSONObject(t.name)?.let { devices[t] = SoundProfile.fromJson(it) }
                }
            }
            val custom = mutableListOf<EqPreset>()
            o.optJSONArray("custom")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val p = arr.optJSONObject(i) ?: continue
                    val b = p.optJSONArray("bands") ?: continue
                    if (b.length() != 10) continue
                    custom += EqPreset(p.optString("name", "Custom"), List(10) { b.optDouble(it, 0.0).toFloat() }, "Custom")
                }
            }
            EngineState(
                perDevice = o.optBoolean("perDevice", true),
                global = SoundProfile.fromJson(o.optJSONObject("global")),
                deviceProfiles = devices,
                customPresets = custom,
            )
        } catch (e: Exception) {
            EngineState()
        }
    }
}
