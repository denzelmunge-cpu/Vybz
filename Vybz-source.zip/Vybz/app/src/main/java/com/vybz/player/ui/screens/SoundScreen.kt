@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.vybz.player.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.SpeakerPhone
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vybz.player.audio.AudioEngine
import com.vybz.player.audio.Biquad
import com.vybz.player.audio.EQ_BAND_Q
import com.vybz.player.audio.EQ_FREQS
import com.vybz.player.audio.EQ_LABELS
import com.vybz.player.audio.EQ_MAX_DB
import com.vybz.player.audio.EqPreset
import com.vybz.player.audio.OutputType
import com.vybz.player.audio.Presets
import com.vybz.player.audio.SoundProfile
import com.vybz.player.ui.MainViewModel
import com.vybz.player.ui.theme.VybzPink
import com.vybz.player.ui.theme.VybzViolet
import java.util.Locale
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt

fun OutputType.icon(): ImageVector = when (this) {
    OutputType.SPEAKER -> Icons.Rounded.SpeakerPhone
    OutputType.WIRED -> Icons.Rounded.Headphones
    OutputType.USB -> Icons.Rounded.Usb
    OutputType.BLUETOOTH -> Icons.Rounded.Bluetooth
}

private fun tipFor(t: OutputType): String = when (t) {
    OutputType.BLUETOOTH -> "Bluetooth: for best quality, open Developer options → Bluetooth audio codec and pick LDAC (990 kbps), aptX HD or AAC if your earbuds support it. Keep phone volume high and use Vybz's preamp instead of cranking EQ boosts."
    OutputType.USB -> "USB-C: digital earphones and DACs get a clean digital signal. Vybz keeps the internal path at 64-bit and dithers the output, so leave the limiter on and avoid boosts above +6 dB."
    OutputType.WIRED -> "3.5mm: wired earphones such as EarPods are bass-light — try the 'Wired EarPods' tuning, then adjust to taste. Crossfeed at 20–40% makes hard-panned old recordings easier on the ears."
    OutputType.SPEAKER -> "Phone speaker: small speakers can't reproduce deep bass; cutting it (the 'Phone Speaker' tuning) gives louder, cleaner sound with less distortion."
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundScreen(vm: MainViewModel) {
    val engine by AudioEngine.state.collectAsState()
    var editing by remember { mutableStateOf(engine.output.type) }
    LaunchedEffect(engine.output.type) { editing = engine.output.type }
    var showSave by remember { mutableStateOf(false) }

    val profile: SoundProfile = if (engine.perDevice) engine.profileFor(editing) else engine.global
    val target: OutputType? = if (engine.perDevice) editing else null
    fun update(f: (SoundProfile) -> SoundProfile) = AudioEngine.update(target, f)

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Sound") },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") } },
            actions = {
                IconButton(onClick = { showSave = true }) { Icon(Icons.Rounded.Save, "Save preset") }
                IconButton(onClick = {
                    update { (if (target != null) Presets.defaultFor(target) else SoundProfile()).copy(enabled = it.enabled) }
                }) { Icon(Icons.Rounded.Refresh, "Reset") }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(bottom = 24.dp)
        ) {
            HiResCard(Modifier.padding(horizontal = 16.dp, vertical = 8.dp))

            // Output / device card
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(engine.output.type.icon(), null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Now playing through", style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(engine.output.name, style = MaterialTheme.typography.titleMedium)
                            Text(engine.output.detail, style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    SwitchRow(
                        "Sound engine",
                        "64-bit DSP · 10-band EQ · limiter · 32-bit float out",
                        profile.enabled
                    ) { v -> update { it.copy(enabled = v) } }
                    SwitchRow(
                        "Auto-switch per output",
                        "Separate tuning for speaker, 3.5mm, USB-C and Bluetooth",
                        engine.perDevice
                    ) { AudioEngine.setPerDevice(it) }
                    if (engine.perDevice) {
                        Text("Editing profile for", style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutputType.values().forEach { t ->
                                FilterChip(
                                    selected = editing == t,
                                    onClick = { editing = t },
                                    label = { Text(t.label + (if (t == engine.output.type) " •" else "")) },
                                    leadingIcon = { Icon(t.icon(), null, Modifier.size(18.dp)) }
                                )
                            }
                        }
                    }
                }
            }

            // EQ curve
            EqCurve(profile, Modifier.fillMaxWidth().height(130.dp).padding(horizontal = 16.dp, vertical = 8.dp))

            // Presets
            PresetRow("Music presets", Presets.music, profile.presetName) { p -> update { it.copy(bands = p.bands, presetName = p.name) } }
            PresetRow("Headphone & speaker tuning", Presets.gear, profile.presetName) { p -> update { it.copy(bands = p.bands, presetName = p.name) } }
            if (engine.customPresets.isNotEmpty()) {
                PresetRow("My presets", engine.customPresets, profile.presetName) { p -> update { it.copy(bands = p.bands, presetName = p.name) } }
            }

            // 10-band graphic EQ
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                for (i in 0 until 10) {
                    VerticalBandSlider(
                        value = profile.bands[i],
                        label = EQ_LABELS[i],
                        enabled = profile.enabled,
                    ) { v ->
                        update { p ->
                            val nb = p.bands.toMutableList().also { it[i] = v }
                            p.copy(bands = nb, presetName = "Custom")
                        }
                    }
                }
            }

            SectionTitle("Tone")
            DbSlider("Preamp", profile.preampDb, -12f..6f) { v -> update { it.copy(preampDb = v) } }
            DbSlider("Bass boost", profile.bassDb, -6f..12f) { v -> update { it.copy(bassDb = v) } }
            DbSlider("Treble / clarity", profile.trebleDb, -6f..8f) { v -> update { it.copy(trebleDb = v) } }

            SectionTitle("Space")
            LabeledSlider("Stereo width", "${(profile.width * 100).roundToInt()}%", profile.width, 0f..2f) { v ->
                update { it.copy(width = (v * 20).roundToInt() / 20f) }
            }
            LabeledSlider(
                "Balance",
                when {
                    profile.balance < -0.01f -> "L ${(-profile.balance * 100).roundToInt()}%"
                    profile.balance > 0.01f -> "R ${(profile.balance * 100).roundToInt()}%"
                    else -> "Centre"
                },
                profile.balance, -1f..1f
            ) { v -> update { it.copy(balance = (v * 20).roundToInt() / 20f) } }
            LabeledSlider("Headphone crossfeed", "${(profile.crossfeed * 100).roundToInt()}%", profile.crossfeed, 0f..1f) { v ->
                update { it.copy(crossfeed = (v * 20).roundToInt() / 20f) }
            }

            SectionTitle("Protection")
            Column(Modifier.padding(horizontal = 16.dp)) {
                SwitchRow("Peak limiter", "Prevents clipping & distortion when boosting", profile.limiter) { v -> update { it.copy(limiter = v) } }
                SwitchRow("Auto headroom", "Lowers gain automatically when you boost EQ", profile.autoHeadroom) { v -> update { it.copy(autoHeadroom = v) } }
                SwitchRow("Mono audio", "Same sound in both ears (one earbud use)", profile.mono) { v -> update { it.copy(mono = v) } }
            }

            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Quality tip · ${(target ?: engine.output.type).label}", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(tipFor(target ?: engine.output.type), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }

    if (showSave) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text("Save as preset") },
            text = { OutlinedTextField(name, { name = it.take(24) }, label = { Text("Preset name") }, singleLine = true) },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    AudioEngine.saveCustomPreset(name.trim(), profile.bands)
                    update { it.copy(presetName = name.trim()) }
                    showSave = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSave = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 2.dp)
    )
}

@Composable
private fun PresetRow(title: String, presets: List<EqPreset>, selected: String, onPick: (EqPreset) -> Unit) {
    Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 4.dp))
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        presets.forEach { p ->
            FilterChip(selected = p.name == selected, onClick = { onPick(p) }, label = { Text(p.name) })
        }
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun DbSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    LabeledSlider(label, String.format(Locale.ROOT, "%+.1f dB", value), value, range) { v ->
        onChange((v * 2).roundToInt() / 2f) // 0.5 dB steps
    }
}

@Composable
fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            Text(label, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            Text(valueText, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun VerticalBandSlider(value: Float, label: String, enabled: Boolean, onChange: (Float) -> Unit) {
    val current by rememberUpdatedState(onChange)
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val track = MaterialTheme.colorScheme.surfaceContainerHighest
    val alpha = if (enabled) 1f else 0.4f
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            if (value == 0f) "0" else String.format(Locale.ROOT, "%+.0f", value),
            fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Canvas(
            Modifier
                .width(28.dp)
                .height(190.dp)
                .semantics {
                    contentDescription = "$label hertz band, ${String.format(Locale.ROOT, "%+.1f", value)} decibels"
                }
                .pointerInput(Unit) {
                    fun toValue(y: Float): Float {
                        val norm = 1f - (y / size.height.toFloat()).coerceIn(0f, 1f)
                        val v = (norm * 2f - 1f) * EQ_MAX_DB
                        return (v * 2).roundToInt() / 2f
                    }
                    detectTapGestures(onDoubleTap = { current(0f) }) { o -> current(toValue(o.y)) }
                }
                .pointerInput(Unit) {
                    detectVerticalDragGestures { change, _ ->
                        change.consume()
                        val norm = 1f - (change.position.y / size.height.toFloat()).coerceIn(0f, 1f)
                        current(((norm * 2f - 1f) * EQ_MAX_DB * 2).roundToInt() / 2f)
                    }
                }
        ) {
            val cx = size.width / 2
            val trackW = 6.dp.toPx()
            drawRoundRect(
                track, topLeft = Offset(cx - trackW / 2, 0f), size = Size(trackW, size.height),
                cornerRadius = CornerRadius(trackW / 2)
            )
            val mid = size.height / 2
            val y = mid - (value / EQ_MAX_DB) * mid
            val top = minOf(mid, y); val bottom = maxOf(mid, y)
            drawRoundRect(
                Brush.verticalGradient(listOf(secondary.copy(alpha = alpha), primary.copy(alpha = alpha))),
                topLeft = Offset(cx - trackW / 2, top), size = Size(trackW, bottom - top + 0.5f),
                cornerRadius = CornerRadius(trackW / 2)
            )
            drawLine(Color.White.copy(alpha = 0.25f), Offset(cx - 9.dp.toPx(), mid), Offset(cx + 9.dp.toPx(), mid), strokeWidth = 1.dp.toPx())
            drawCircle(Color.White.copy(alpha = alpha), radius = 9.dp.toPx(), center = Offset(cx, y))
            drawCircle(primary.copy(alpha = alpha), radius = 5.dp.toPx(), center = Offset(cx, y))
        }
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EqCurve(p: SoundProfile, modifier: Modifier) {
    val points = remember(p) {
        val fs = 48000.0
        val filters = ArrayList<Biquad>()
        for (i in 0 until 10) if (p.bands[i] != 0f) filters += Biquad().also { it.setPeaking(fs, EQ_FREQS[i], EQ_BAND_Q, p.bands[i].toDouble()) }
        if (p.bassDb != 0f) filters += Biquad().also { it.setLowShelf(fs, 105.0, 0.707, p.bassDb.toDouble()) }
        if (p.trebleDb != 0f) filters += Biquad().also { it.setHighShelf(fs, 6500.0, 0.707, p.trebleDb.toDouble()) }
        val n = 120
        FloatArray(n) { k ->
            val f = 20.0 * 10.0.pow(k / (n - 1.0) * log10(20000.0 / 20.0))
            (filters.sumOf { it.magnitudeDb(f, fs) } + p.preampDb).toFloat()
        }
    }
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val active = p.enabled
    Canvas(modifier) {
        val maxDb = 18f
        val mid = size.height / 2
        drawLine(grid, Offset(0f, mid), Offset(size.width, mid), strokeWidth = 1.dp.toPx())
        listOf(100f, 1000f, 10000f).forEach { f ->
            val x = (log10(f / 20f) / log10(1000f)) * size.width
            drawLine(grid, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1.dp.toPx())
        }
        val path = Path()
        val fill = Path()
        points.forEachIndexed { i, db ->
            val x = i / (points.size - 1f) * size.width
            val y = mid - (db.coerceIn(-maxDb, maxDb) / maxDb) * mid
            if (i == 0) { path.moveTo(x, y); fill.moveTo(x, mid); fill.lineTo(x, y) } else { path.lineTo(x, y); fill.lineTo(x, y) }
        }
        fill.lineTo(size.width, mid); fill.close()
        val a = if (active) 1f else 0.35f
        drawPath(fill, Brush.verticalGradient(listOf(primary.copy(alpha = 0.35f * a), Color.Transparent)))
        drawPath(
            path,
            Brush.horizontalGradient(listOf(primary.copy(alpha = a), secondary.copy(alpha = a), primary.copy(alpha = a))),
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}
