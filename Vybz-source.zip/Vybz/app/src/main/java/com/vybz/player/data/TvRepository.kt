package com.vybz.player.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

enum class TvRegion(val label: String) { KENYA("Kenya"), AFRICA("Africa"), INTERNATIONAL("International"), MY("My channels") }

/**
 * A TV channel. Either [streamUrl] (plays inside Vybz) or [youtubeQuery] (opens the
 * broadcaster's official YouTube live stream in the YouTube app) is set.
 */
data class TvChannel(
    val id: String,
    val name: String,
    val region: TvRegion,
    val category: String,
    val country: String,
    val streamUrl: String? = null,
    val youtubeQuery: String? = null,
    val description: String = "",
) {
    val playsInApp: Boolean get() = !streamUrl.isNullOrBlank()

    /** YouTube search filtered to live videos (sp=EgJAAQ%3D%3D), so the current live stream shows first. */
    val youtubeUrl: String?
        get() = youtubeQuery?.let {
            "https://www.youtube.com/results?search_query=" + URLEncoder.encode(it, "UTF-8") + "&sp=EgJAAQ%253D%253D"
        }

    /** Where to send the user when the channel doesn't play inside the app. */
    val externalUrl: String?
        get() = youtubeUrl ?: description.takeIf { it.startsWith("http") }

    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("region", region.name)
        .put("category", category).put("country", country).put("streamUrl", streamUrl ?: "")
        .put("youtubeQuery", youtubeQuery ?: "").put("description", description)

    companion object {
        fun fromJson(o: JSONObject): TvChannel? {
            val id = o.optString("id"); if (id.isBlank()) return null
            return TvChannel(
                id = id,
                name = o.optString("name", "Channel"),
                region = try { TvRegion.valueOf(o.optString("region", "MY")) } catch (e: Exception) { TvRegion.MY },
                category = o.optString("category", "General"),
                country = o.optString("country"),
                streamUrl = o.optString("streamUrl").ifBlank { null },
                youtubeQuery = o.optString("youtubeQuery").ifBlank { null },
                description = o.optString("description"),
            )
        }
    }
}

/**
 * Featured channels are limited to broadcasters' own, free, official live streams.
 * Streams that only exist on a broadcaster's YouTube channel open in the YouTube app.
 * Links can change over time; update this list when a broadcaster moves its stream.
 */
object TvRepository {

    val featured: List<TvChannel> = listOf(
        // ---- Kenya (official live streams on the broadcasters' YouTube channels)
        yt("ke-citizen", "Citizen TV Kenya", TvRegion.KENYA, "News & entertainment", "Kenya", "Citizen TV Kenya live"),
        yt("ke-ntv", "NTV Kenya", TvRegion.KENYA, "News", "Kenya", "NTV Kenya live"),
        yt("ke-ktn", "KTN News Kenya", TvRegion.KENYA, "News", "Kenya", "KTN News Kenya live"),
        yt("ke-kbc", "KBC Channel 1", TvRegion.KENYA, "Public broadcaster", "Kenya", "KBC Channel 1 live"),
        yt("ke-k24", "K24 TV", TvRegion.KENYA, "News", "Kenya", "K24 TV live"),
        yt("ke-tv47", "TV47 Kenya", TvRegion.KENYA, "News", "Kenya", "TV47 Kenya live"),
        yt("ke-inooro", "Inooro TV", TvRegion.KENYA, "Kikuyu language", "Kenya", "Inooro TV live"),
        yt("ke-ramogi", "Ramogi TV", TvRegion.KENYA, "Luo language", "Kenya", "Ramogi TV live"),
        // ---- Africa
        yt("af-africanews", "Africanews", TvRegion.AFRICA, "News", "Pan-African", "Africanews live"),
        yt("af-sabc", "SABC News", TvRegion.AFRICA, "News", "South Africa", "SABC News live"),
        yt("af-arise", "Arise News", TvRegion.AFRICA, "News", "Nigeria", "Arise News live"),
        yt("af-channels", "Channels Television", TvRegion.AFRICA, "News", "Nigeria", "Channels Television live"),
        // ---- International (official free streams that play inside Vybz)
        hls("in-aje", "Al Jazeera English", "News", "Qatar", "https://live-hls-web-aje.getaj.net/AJE/index.m3u8"),
        hls("in-dw", "DW English", "News", "Germany", "https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8"),
        hls("in-f24", "France 24 English", "News", "France", "https://static.france24.com/live/F24_EN_HI_HLS/live_web.m3u8"),
        hls("in-nhk", "NHK World-Japan", "News & culture", "Japan", "https://nhkwlive-ojp.akamaized.net/hls/live/2003459/nhkwlive-ojp-en/index.m3u8"),
        hls("in-trt", "TRT World", "News", "Türkiye", "https://tv-trtworld.medya.trt.com.tr/master.m3u8"),
        hls("in-cgtn", "CGTN", "News", "China", "https://news.cgtn.com/resource/live/english/cgtn-news.m3u8"),
        yt("in-sky", "Sky News", TvRegion.INTERNATIONAL, "News", "United Kingdom", "Sky News live"),
        yt("in-euronews", "Euronews", TvRegion.INTERNATIONAL, "News", "Europe", "Euronews English live"),
        yt("in-abcau", "ABC News Australia", TvRegion.INTERNATIONAL, "News", "Australia", "ABC News Australia live"),
    )

    private fun yt(id: String, name: String, region: TvRegion, cat: String, country: String, q: String) =
        TvChannel(id, name, region, cat, country, youtubeQuery = q, description = "Official live stream on YouTube")

    private fun hls(id: String, name: String, cat: String, country: String, url: String) =
        TvChannel(id, name, TvRegion.INTERNATIONAL, cat, country, streamUrl = url, description = "Official free stream")

    private lateinit var prefs: SharedPreferences
    private val _custom = MutableStateFlow<List<TvChannel>>(emptyList())
    val custom: StateFlow<List<TvChannel>> = _custom.asStateFlow()
    private val _favourites = MutableStateFlow<Set<String>>(emptySet())
    val favourites: StateFlow<Set<String>> = _favourites.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.getSharedPreferences("vybz_tv", Context.MODE_PRIVATE)
        _favourites.value = prefs.getStringSet("favourites", emptySet())?.toSet() ?: emptySet()
        val list = mutableListOf<TvChannel>()
        try {
            val arr = JSONArray(prefs.getString("custom", "[]"))
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { TvChannel.fromJson(it) }?.let { list += it }
        } catch (e: Exception) { }
        _custom.value = list
    }

    fun all(): List<TvChannel> = featured + _custom.value

    fun toggleFavourite(id: String) {
        val cur = _favourites.value
        _favourites.value = if (id in cur) cur - id else cur + id
        if (::prefs.isInitialized) prefs.edit().putStringSet("favourites", _favourites.value).apply()
    }

    fun addCustom(name: String, url: String) {
        val u = url.trim()
        val isYoutube = u.contains("youtube.com", true) || u.contains("youtu.be", true)
        val ch = TvChannel(
            id = "my-" + System.currentTimeMillis(),
            name = name.ifBlank { "My channel" },
            region = TvRegion.MY,
            category = "My channel",
            country = "",
            streamUrl = if (isYoutube) null else u,
            youtubeQuery = null,
            description = if (isYoutube) u else "Added by link",
        )
        _custom.value = _custom.value + ch
        saveCustom()
    }

    fun removeCustom(id: String) {
        _custom.value = _custom.value.filterNot { it.id == id }
        saveCustom()
    }

    private fun saveCustom() {
        if (!::prefs.isInitialized) return
        val arr = JSONArray()
        _custom.value.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("custom", arr.toString()).apply()
    }
}
