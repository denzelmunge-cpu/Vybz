package com.vybz.player.audio

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow

/**
 * The Vybz tone chain, in 64-bit floating point:
 * mono → preamp → 10-band EQ → bass shelf → treble shelf → stereo width → crossfeed → balance.
 *
 * Settings are read from the lock-free snapshot [AudioEngine.dsp] and applied on the audio
 * thread, so the UI can change them while music plays.
 */
class DspCore {
    private var sampleRate = 44100.0
    private var channels = 2

    private val eq = Array(10) { Biquad() }
    private val eqActive = BooleanArray(10)
    private val bass = Biquad()
    private val treble = Biquad()
    private val xfeedLp = Biquad()

    private var appliedVersion = -1L
    var enabled = false; private set
    var limiterOn = true; private set
    private var bassActive = false
    private var trebleActive = false
    private var preamp = 1.0
    private var width = 1.0
    private var balL = 1.0
    private var balR = 1.0
    private var xfeed = 0.0
    private var mono = false

    fun configure(rate: Int, channelCount: Int) {
        sampleRate = rate.toDouble().coerceAtLeast(8000.0)
        channels = channelCount.coerceIn(1, Biquad.MAX_CHANNELS)
        reset()
        appliedVersion = -1L
    }

    fun reset() {
        eq.forEach { it.reset() }
        bass.reset(); treble.reset(); xfeedLp.reset()
    }

    /** Picks up new settings if the user changed anything. */
    fun sync() {
        val p = AudioEngine.dsp
        if (p.version != appliedVersion) apply(p)
    }

    private fun apply(p: DspParams) {
        appliedVersion = p.version
        enabled = p.enabled
        limiterOn = p.limiter
        val fs = sampleRate
        for (i in 0 until 10) {
            val g = p.bands.getOrElse(i) { 0f }.toDouble()
            eqActive[i] = abs(g) > 0.05
            if (eqActive[i]) eq[i].setPeaking(fs, EQ_FREQS[i], EQ_BAND_Q, g) else eq[i].setBypass()
        }
        bassActive = abs(p.bassDb) > 0.05
        if (bassActive) bass.setLowShelf(fs, 105.0, 0.707, p.bassDb.toDouble()) else bass.setBypass()
        trebleActive = abs(p.trebleDb) > 0.05
        if (trebleActive) treble.setHighShelf(fs, 6500.0, 0.707, p.trebleDb.toDouble()) else treble.setBypass()
        preamp = 10.0.pow(p.preampDb / 20.0)
        width = p.width.toDouble().coerceIn(0.0, 2.0)
        val b = p.balance.toDouble().coerceIn(-1.0, 1.0)
        balL = if (b > 0) 1.0 - b else 1.0
        balR = if (b < 0) 1.0 + b else 1.0
        xfeed = p.crossfeed.toDouble().coerceIn(0.0, 1.0) * 0.45
        if (xfeed > 0) xfeedLp.setLowPass(fs, 700.0, 0.5)
        mono = p.mono
    }

    /** Processes one interleaved frame in place (values roughly in -1..1). */
    fun process(frame: DoubleArray) {
        if (!enabled) return
        val ch = channels
        val stereo = ch == 2
        if (mono && stereo) {
            val m = (frame[0] + frame[1]) * 0.5
            frame[0] = m; frame[1] = m
        }
        for (c in 0 until ch) {
            var s = frame[c] * preamp
            for (i in 0 until 10) if (eqActive[i]) s = eq[i].process(s, c)
            if (bassActive) s = bass.process(s, c)
            if (trebleActive) s = treble.process(s, c)
            frame[c] = s
        }
        if (stereo) {
            var l = frame[0]
            var r = frame[1]
            if (width != 1.0) {
                val mid = (l + r) * 0.5
                val side = (l - r) * 0.5 * width
                l = mid + side; r = mid - side
            }
            if (xfeed > 0.0) {
                val fromR = xfeedLp.process(r, 0)
                val fromL = xfeedLp.process(l, 1)
                val norm = 1.0 / (1.0 + xfeed)
                l = (l + xfeed * fromR) * norm
                r = (r + xfeed * fromL) * norm
            }
            frame[0] = l * balL
            frame[1] = r * balR
        }
    }
}

/** Instant-attack, smooth-release peak limiter. Keeps output below full scale. */
class PeakLimiter {
    private var gain = 1.0
    private var release = 0.9995
    private val threshold = 0.977 // ≈ -0.2 dBFS

    fun configure(rate: Int) {
        release = exp(-1.0 / (0.25 * rate.coerceAtLeast(8000)))
        gain = 1.0
    }

    fun reset() { gain = 1.0 }

    fun process(frame: DoubleArray, ch: Int) {
        var peak = 0.0
        for (c in 0 until ch) { val a = abs(frame[c]); if (a > peak) peak = a }
        val target = if (peak > threshold) threshold / peak else 1.0
        gain = if (target < gain) target else target + (gain - target) * release
        if (gain < 0.99999) for (c in 0 until ch) frame[c] *= gain
    }
}

/**
 * "Hi-Res Restore": a gentle harmonic exciter. Compressed files (MP3/AAC) lose most content
 * above ~16 kHz; this generates soft 2nd-order harmonics from the 5–12 kHz band so the top
 * octave sounds open again. Run after upsampling so new harmonics can extend above 20 kHz
 * without aliasing. It cannot recover the original recording — it adds plausible air.
 */
class Exciter {
    private val hpA = Biquad()
    private val hpB = Biquad()
    private val lp = Biquad()
    private val hpOut = Biquad()
    private val hpOut2 = Biquad()

    fun configure(rate: Int) {
        val fs = rate.toDouble()
        hpA.setHighPass(fs, 5000.0, 0.707)
        hpB.setHighPass(fs, 5000.0, 0.707)
        // keep the source band below fs/4 so its 2nd harmonic stays below Nyquist
        lp.setLowPass(fs, minOf(12000.0, fs * 0.23), 0.707)
        val outCut = minOf(10000.0, fs * 0.2)
        hpOut.setHighPass(fs, outCut, 0.707)
        hpOut2.setHighPass(fs, outCut, 0.707)
        reset()
    }

    fun reset() {
        hpA.reset(); hpB.reset(); lp.reset(); hpOut.reset(); hpOut2.reset()
    }

    /** amount 0..1 */
    fun process(x: Double, c: Int, amount: Double): Double {
        val band = lp.process(hpB.process(hpA.process(x, c), c), c)
        val rectified = abs(band)                 // full-wave → 2nd harmonics (+ DC)
        val harmonics = hpOut2.process(hpOut.process(rectified, c), c) // remove DC & lows
        return x + harmonics * amount * 1.6
    }
}
