package com.vybz.player

/** Developer credit — shown only in the Credits section of the About screen. */
const val DEVELOPER_NAME = "Sembele Denzel"
const val DEVELOPER_CREDIT = "Developed by $DEVELOPER_NAME"
