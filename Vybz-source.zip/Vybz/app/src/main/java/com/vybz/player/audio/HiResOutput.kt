package com.vybz.player.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.os.Build
import androidx.annotation.RequiresApi

/** Chooses the best output sample rate for the current device. */
object HiResOutput {

    const val RATE_AUTO = 0
    const val RATE_ORIGINAL = 1

    fun targetRate(context: Context, inRate: Int, pref: Int): Int {
        val rate = when (pref) {
            RATE_ORIGINAL -> inRate
            RATE_AUTO -> autoRate(context, inRate)
            else -> pref
        }
        // AudioTrack limits: 192 kHz on Android 7+, 96 kHz before that.
        return rate.coerceIn(8000, if (Build.VERSION.SDK_INT >= 24) 192000 else 96000)
    }

    private fun autoRate(context: Context, inRate: Int): Int {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val native = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull()
            ?.takeIf { it in 8000..384000 } ?: 48000
        if (Build.VERSION.SDK_INT < 23) return native

        val device = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .maxByOrNull { OutputMonitor.rankType(it.type) } ?: return native
        if (OutputMonitor.rankType(device.type) != 3) return native // not USB → system mixer rate

        // USB DAC / digital earphones
        if (Build.VERSION.SDK_INT >= 34) {
            val mixerRate = try { UsbMixer.request(am, device) } catch (t: Throwable) { 0 }
            if (mixerRate > 0) return mixerRate
        }
        val rates = device.sampleRates
        val best = rates.filter { it in 44100..192000 }.maxOrNull()
        return best ?: maxOf(native, inRate.coerceAtMost(192000))
    }

    fun encodingRank(e: Int): Int = when (e) {
        AudioFormat.ENCODING_PCM_FLOAT -> 4
        AudioFormat.ENCODING_PCM_32BIT -> 3
        AudioFormat.ENCODING_PCM_24BIT_PACKED -> 2
        AudioFormat.ENCODING_PCM_16BIT -> 1
        else -> 0
    }

    fun describeRate(rate: Int): String =
        if (rate % 1000 == 0) "${rate / 1000} kHz" else String.format(java.util.Locale.ROOT, "%.1f kHz", rate / 1000.0)
}

/** Kept separate so older Android versions never load the API 34 classes. */
@RequiresApi(34)
internal object UsbMixer {
    private val cache = HashMap<Int, Int>()

    /**
     * Android 14+: ask the system to run the USB output stream at the DAC's highest
     * sample rate / bit depth instead of the default 48 kHz mixer.
     */
    fun request(am: AudioManager, device: AudioDeviceInfo): Int {
        cache[device.id]?.let { return it }
        val attrs = android.media.AudioAttributes.Builder()
            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val candidates = am.getSupportedMixerAttributes(device).filter {
            it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_DEFAULT &&
                it.format.sampleRate in 44100..192000
        }
        val best = candidates.maxWithOrNull(
            compareBy<AudioMixerAttributes>({ it.format.sampleRate }, { HiResOutput.encodingRank(it.format.encoding) })
        )
        val rate = if (best != null && am.setPreferredMixerAttributes(attrs, device, best)) best.format.sampleRate else 0
        cache[device.id] = rate
        return rate
    }

}
