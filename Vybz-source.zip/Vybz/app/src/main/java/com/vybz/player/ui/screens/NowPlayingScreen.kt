@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.vybz.player.ui.screens

import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.SystemClock
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.FormatQuote
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.vybz.player.audio.AudioEngine
import com.vybz.player.audio.OutputType
import com.vybz.player.data.AppSettings
import com.vybz.player.data.ArtworkLoader
import com.vybz.player.data.SleepTimer
import com.vybz.player.data.Song
import com.vybz.player.ui.MainViewModel
import com.vybz.player.ui.NowPlayingExtras
import com.vybz.player.ui.Screen
import com.vybz.player.ui.components.Artwork
import com.vybz.player.ui.components.formatTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(vm: MainViewModel) {
    val state by vm.player.collectAsState()
    val extras by vm.extras.collectAsState()
    val engine by AudioEngine.state.collectAsState()
    val hq by AudioEngine.hq.collectAsState()
    val song = state.song ?: return

    var showLyrics by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showTimer by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showLyricsSearch by remember { mutableStateOf(false) }

    val art = extras.artwork
    val fallback = MaterialTheme.colorScheme.primaryContainer
    val dominant = remember(art, fallback) { art?.let { Color(ArtworkLoader.dominantColor(it)) } ?: fallback }
    val bg by animateColorAsState(dominant, tween(700), label = "bg")

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .background(Brush.verticalGradient(listOf(bg.copy(alpha = 0.85f), bg.copy(alpha = 0.35f), Color.Black)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .pointerInput(Unit) {
                // Swipe down to close
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total > 220f) vm.nowPlayingOpen = false },
                ) { _, dy -> total += dy }
            }
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top bar
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.nowPlayingOpen = false }) {
                    Icon(Icons.Rounded.KeyboardArrowDown, "Close", Modifier.size(32.dp))
                }
                Spacer(Modifier.weight(1f))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.12f),
                    modifier = Modifier.clip(RoundedCornerShape(50)).clickable {
                        vm.nowPlayingOpen = false; vm.navigate(Screen.Sound)
                    }
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Headphones, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        val p = engine.active
                        Text(
                            "${engine.output.name} · ${if (p.enabled) p.presetName else "DSP off"}",
                            style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 190.dp)
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                val ctx = LocalContext.current
                IconButton(onClick = {
                    shareText(ctx, "Listening to \"${song.title}\" by ${song.artist} on Vybz 🎧")
                }) { Icon(Icons.Rounded.Share, "Share this song") }
                IconButton(onClick = { showSpeed = true }) { Icon(Icons.Rounded.Speed, "Playback speed") }
            }

            Spacer(Modifier.height(16.dp))

            // Artwork or lyrics
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Crossfade(targetState = showLyrics && !song.isRadio, label = "lyrics") { lyricsMode ->
                    if (lyricsMode) {
                        LyricsView(
                            extras = extras,
                            positionMs = state.positionMs,
                            onSeek = { vm.seekTo(it) },
                            onSearch = { showLyricsSearch = true },
                            onRetry = { vm.loadLyrics(song, force = true) },
                            onLoad = { vm.loadLyrics(song) },
                        )
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Artwork(
                                song,
                                Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .shadow(24.dp, RoundedCornerShape(22.dp))
                                    .clickable { if (!song.isRadio) showLyrics = true },
                                sizePx = 720, corner = 22.dp, bitmap = art
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            // Title / artist
            val live = state.liveTitle
            Text(
                if (song.isRadio && live != null) live else song.title,
                style = MaterialTheme.typography.headlineMedium, maxLines = 1,
                modifier = Modifier.fillMaxWidth().basicMarquee()
            )
            Text(
                if (song.isRadio) listOf(song.title, song.album).filter { it.isNotBlank() }.joinToString(" · ")
                else listOf(song.artist, song.album).filter { it.isNotBlank() }.joinToString(" · "),
                style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.fillMaxWidth().clickable(enabled = !song.isRadio) {
                    vm.nowPlayingOpen = false; goToArtist(vm, song)
                }
            )
            val hqNow = hq
            if (hqNow != null) {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                        modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable {
                            vm.nowPlayingOpen = false; vm.navigate(Screen.Sound)
                        }
                    ) {
                        Text(
                            (if (hqNow.upscaled) "HI-RES  " else "32-BIT  ") +
                                "${hqNow.sourceLabel}  →  ${hqNow.shortLabel}",
                            fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            if (song.isRadio) {
                // Live stream: no seeking
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFE53935)) {
                        Text(
                            "● LIVE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (state.buffering) "Connecting…" else "Live radio · ${formatTime(state.positionMs)} listened",
                        style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.7f)
                    )
                }
            } else {
            // Seek bar
            var dragging by remember { mutableStateOf(false) }
            var dragValue by remember { mutableFloatStateOf(0f) }
            val dur = state.durationMs.coerceAtLeast(1L)
            val pos = if (dragging) dragValue else (state.positionMs.toFloat() / dur).coerceIn(0f, 1f)
            Slider(
                value = pos,
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = { vm.seekTo((dragValue * dur).toLong()); dragging = false },
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.White,
                    inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime((pos * dur).toLong()), style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.7f))
                Spacer(Modifier.weight(1f))
                Text(formatTime(state.durationMs), style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.7f))
            }
            }

            // Transport controls
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.toggleShuffle() }) {
                    Icon(
                        Icons.Rounded.Shuffle, "Shuffle",
                        tint = if (state.shuffle) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.7f)
                    )
                }
                IconButton(onClick = { vm.previous() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(40.dp))
                }
                FilledIconButton(
                    onClick = { vm.playPause() },
                    modifier = Modifier.size(76.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White, contentColor = Color.Black)
                ) {
                    if (state.buffering && !state.isPlaying) {
                        CircularProgressIndicator(Modifier.size(30.dp), color = Color.Black, strokeWidth = 3.dp)
                    } else {
                        Icon(
                            if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            "Play/Pause", Modifier.size(44.dp)
                        )
                    }
                }
                IconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(40.dp))
                }
                IconButton(onClick = { vm.cycleRepeat() }) {
                    Icon(
                        if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        "Repeat",
                        tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary
                        else Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            // Bottom actions
            val timerEnd by SleepTimer.endAt.collectAsState()
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                if (song.isRadio) {
                    val favs by com.vybz.player.data.RadioRepository.favourites.collectAsState()
                    val station = com.vybz.player.data.RadioRepository.stationFor(song.key)
                    val isFav = favs.any { it.uuid == song.radioId }
                    BottomAction(
                        if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (isFav) "Saved" else "Save", isFav
                    ) { station?.let { com.vybz.player.data.RadioRepository.toggleFavourite(it) } }
                } else {
                    BottomAction(Icons.Rounded.FormatQuote, "Lyrics", showLyrics) { showLyrics = !showLyrics }
                }
                BottomAction(Icons.Rounded.QueueMusic, "Queue", false) { showQueue = true }
                BottomAction(Icons.Rounded.Equalizer, "Sound", engine.active.enabled) {
                    vm.nowPlayingOpen = false; vm.navigate(Screen.Sound)
                }
                BottomAction(Icons.Rounded.Info, "Info", false) { showInfo = true; vm.loadArtistInfo() }
                BottomAction(Icons.Rounded.Timer, if (timerEnd > 0) "On" else "Timer", timerEnd > 0) { showTimer = true }
            }
        }
    }

    if (showQueue) {
        ModalBottomSheet(onDismissRequest = { showQueue = false }, sheetState = rememberModalBottomSheetState()) {
            QueueSheet(vm, state.queue, state.index)
        }
    }
    if (showInfo) {
        ModalBottomSheet(onDismissRequest = { showInfo = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            InfoSheet(song, extras)
        }
    }
    if (showTimer) SleepTimerDialog { showTimer = false }
    if (showSpeed) SpeedDialog { showSpeed = false }
    if (showLyricsSearch) {
        LyricsSearchDialog(song, onDismiss = { showLyricsSearch = false }) { t, a ->
            showLyricsSearch = false
            vm.loadLyrics(song, force = true, title = t, artist = a)
        }
    }
}

@Composable
private fun BottomAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (active) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.85f))
        Text(label, fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
    }
}

@Composable
private fun LyricsView(
    extras: NowPlayingExtras,
    positionMs: Long,
    onSeek: (Long) -> Unit,
    onSearch: () -> Unit,
    onRetry: () -> Unit,
    onLoad: () -> Unit,
) {
    val lyrics = extras.lyrics
    LaunchedEffect(extras.songKey) { if (extras.lyrics == null && !extras.lyricsLoading) onLoad() }

    if (extras.lyricsLoading || lyrics == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else when {
        lyrics.synced.isNotEmpty() -> {
            val lines = lyrics.synced
            val current = lines.indexOfLast { it.timeMs <= positionMs + 250 }
            val listState = rememberLazyListState()
            LaunchedEffect(current) {
                if (current >= 0) listState.animateScrollToItem((current - 2).coerceAtLeast(0))
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 40.dp)
            ) {
                itemsIndexed(lines) { i, line ->
                    val active = i == current
                    Text(
                        line.text.ifBlank { "♪" },
                        fontSize = if (active) 26.sp else 22.sp,
                        lineHeight = 32.sp,
                        fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Bold,
                        color = Color.White.copy(alpha = if (active) 1f else if (i < current) 0.35f else 0.5f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSeek(line.timeMs) }
                            .padding(vertical = 8.dp, horizontal = 4.dp)
                    )
                }
                item {
                    Text(
                        "Lyrics: ${lyrics.source}", fontSize = 12.sp, color = Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.padding(top = 24.dp).clickable { onSearch() }
                    )
                }
            }
        }
        !lyrics.plain.isNullOrBlank() -> {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp)) {
                Text(lyrics.plain.orEmpty(), fontSize = 20.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Lyrics: ${lyrics.source} (not time-synced)", fontSize = 12.sp, color = Color.White.copy(alpha = 0.4f),
                    modifier = Modifier.padding(top = 24.dp).clickable { onSearch() }
                )
            }
        }
        else -> Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("No lyrics found", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(6.dp))
            Text(
                if (AppSettings.current.onlineEnabled) "Check the song title/artist tags, or search manually."
                else "Online lyrics are turned off in Settings.",
                textAlign = TextAlign.Center, color = Color.White.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onRetry) { Text("Retry") }
                OutlinedButton(onClick = onSearch) { Text("Search…") }
            }
        }
    }
}

@Composable
private fun QueueSheet(vm: MainViewModel, queue: List<Song>, index: Int) {
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (index - 1).coerceAtLeast(0))
    Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
        Text(
            "Up next · ${queue.size} songs", style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().height(480.dp)) {
            itemsIndexed(queue) { i, s ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (i == index) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent)
                        .clickable { vm.playQueueIndex(i) }
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Artwork(s, Modifier.size(44.dp), sizePx = 150, corner = 8.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (i == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (i != index) {
                        IconButton(onClick = { vm.removeFromQueue(i) }) { Icon(Icons.Rounded.Close, "Remove") }
                    }
                }
            }
        }
    }
}

private data class FileDetails(val format: String, val bitrate: String, val sampleRate: String, val bits: String)

@Composable
private fun InfoSheet(song: Song, extras: NowPlayingExtras) {
    val context = LocalContext.current
    val details by produceState(FileDetails("", "", "", ""), song.key) {
        value = withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, song.uri)
                val br = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L
                var sr = ""
                var bits = ""
                if (Build.VERSION.SDK_INT >= 31) {
                    sr = r.extractMetadata(38)?.let { "${it.toInt() / 1000.0} kHz" } ?: ""
                    bits = r.extractMetadata(39)?.let { "$it-bit" } ?: ""
                }
                val mime = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: song.mime
                FileDetails(
                    mime.substringAfter('/').uppercase(Locale.ROOT),
                    if (br > 0) "${br / 1000} kbps" else "",
                    sr, bits
                )
            } catch (e: Exception) {
                FileDetails(song.mime.substringAfter('/').uppercase(Locale.ROOT), "", "", "")
            } finally {
                try { r.release() } catch (e: Exception) { }
            }
        }
    }
    Column(
        Modifier.fillMaxWidth().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Text(song.title, style = MaterialTheme.typography.titleLarge)
        Text(song.artist, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        InfoRow("Album", song.album)
        val info = extras.info
        if (info != null) {
            InfoRow("Genre", info.genre)
            InfoRow("Released", info.year)
        }
        if (song.year > 0) InfoRow("Year (tag)", song.year.toString())
        InfoRow("Duration", formatTime(song.duration))
        HorizontalDivider(Modifier.padding(vertical = 10.dp))
        Text("Audio quality", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        InfoRow("Format", details.format)
        InfoRow("Bitrate", details.bitrate)
        InfoRow("Sample rate", details.sampleRate)
        InfoRow("Bit depth", details.bits)
        if (song.size > 0) InfoRow("File size", String.format(Locale.ROOT, "%.1f MB", song.size / 1048576.0))
        InfoRow("Location", song.path)
        val artist = extras.artist
        if (artist != null && artist.bio.isNotBlank()) {
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Text("About ${artist.name}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(4.dp))
            Text(artist.bio, style = MaterialTheme.typography.bodyMedium)
            Text("Source: Wikipedia", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.width(110.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, Modifier.weight(1f))
    }
}

@Composable
private fun SleepTimerDialog(onDismiss: () -> Unit) {
    val end by SleepTimer.endAt.collectAsState()
    var now by remember { mutableStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(end) {
        while (end > 0) { now = SystemClock.elapsedRealtime(); delay(1000) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep timer") },
        text = {
            Column {
                if (end > 0) {
                    Text("Music stops in ${formatTime(end - now)}", color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(8.dp))
                }
                listOf(10, 15, 30, 45, 60, 90).forEach { m ->
                    Text(
                        "$m minutes",
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                            .clickable { SleepTimer.start(m); onDismiss() }
                            .padding(vertical = 12.dp, horizontal = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            if (end > 0) TextButton(onClick = { SleepTimer.cancel(); onDismiss() }) { Text("Turn off") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun SpeedDialog(onDismiss: () -> Unit) {
    val s by AppSettings.state.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback speed & pitch") },
        text = {
            Column {
                Text("Speed ${String.format(Locale.ROOT, "%.2fx", s.speed)}")
                Slider(
                    value = s.speed, valueRange = 0.5f..2f, steps = 29,
                    onValueChange = { v -> AppSettings.update { it.copy(speed = (v * 20).toInt() / 20f) } }
                )
                Text("Pitch ${String.format(Locale.ROOT, "%.2fx", s.pitch)}")
                Slider(
                    value = s.pitch, valueRange = 0.5f..2f, steps = 29,
                    onValueChange = { v -> AppSettings.update { it.copy(pitch = (v * 20).toInt() / 20f) } }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { AppSettings.update { it.copy(speed = 1f, pitch = 1f) } }) { Text("Reset") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
private fun LyricsSearchDialog(song: Song, onDismiss: () -> Unit, onSearch: (String, String) -> Unit) {
    var title by remember { mutableStateOf(com.vybz.player.data.OnlineRepository.cleanTitle(song.title)) }
    var artist by remember { mutableStateOf(if (song.artist == "Unknown artist") "" else song.artist) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search lyrics") },
        text = {
            Column {
                OutlinedTextField(title, { title = it }, label = { Text("Song title") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(artist, { artist = it }, label = { Text("Artist") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = { onSearch(title.trim(), artist.trim()) }) { Text("Search") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
