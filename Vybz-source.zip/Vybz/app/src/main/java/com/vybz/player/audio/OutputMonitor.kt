package com.vybz.player.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

data class OutputInfo(
    val type: OutputType,
    val name: String,
    val detail: String,
)

/**
 * Detects which output is in use (speaker, 3.5mm, USB-C, Bluetooth) so Vybz can switch
 * to the sound profile tuned for it automatically.
 */
class OutputMonitor(private val context: Context, private val onChange: (OutputInfo) -> Unit) {

    private val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val handler = Handler(Looper.getMainLooper())

    fun start() {
        if (Build.VERSION.SDK_INT >= 23) {
            am.registerAudioDeviceCallback(object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = refreshSoon()
                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = refreshSoon()
            }, handler)
        } else {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_HEADSET_PLUG)
                addAction("android.bluetooth.a2dp.profile.action.CONNECTION_STATE_CHANGED")
                addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            }
            ContextCompat.registerReceiver(context, object : BroadcastReceiver() {
                override fun onReceive(c: Context?, intent: Intent?) = refreshSoon()
            }, filter, ContextCompat.RECEIVER_EXPORTED)
        }
        onChange(detect())
    }

    private fun refreshSoon() {
        // Routing settles a moment after the device event.
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ onChange(detect()) }, 400)
    }

    fun detect(): OutputInfo {
        if (Build.VERSION.SDK_INT >= 23) {
            val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val best = devices.maxByOrNull { rank(it.type) }
            if (best != null && rank(best.type) > 0) {
                val type = typeOf(best.type)
                val name = best.productName?.toString()?.takeIf { it.isNotBlank() && it != android.os.Build.MODEL }
                    ?: type.label
                val rates = best.sampleRates
                val maxRate = if (rates.isNotEmpty()) rates.max() else 0
                val detail = buildString {
                    append(type.label)
                    if (maxRate > 48000) append(" · up to ${maxRate / 1000} kHz (Hi-Res capable)")
                    else if (maxRate > 0) append(" · ${maxRate / 1000.0} kHz")
                    if (type == OutputType.BLUETOOTH) append(" · codec set by phone")
                }
                return OutputInfo(type, name, detail)
            }
            return OutputInfo(OutputType.SPEAKER, OutputType.SPEAKER.label, "Built-in speaker")
        }
        @Suppress("DEPRECATION")
        return when {
            am.isBluetoothA2dpOn -> OutputInfo(OutputType.BLUETOOTH, "Bluetooth audio", "Bluetooth")
            am.isWiredHeadsetOn -> OutputInfo(OutputType.WIRED, "Headphones", "Wired / USB-C")
            else -> OutputInfo(OutputType.SPEAKER, OutputType.SPEAKER.label, "Built-in speaker")
        }
    }

    private fun rank(t: Int): Int = rankType(t)

    private fun typeOf(t: Int): OutputType = when (rank(t)) {
        4 -> OutputType.BLUETOOTH
        3 -> OutputType.USB
        2 -> OutputType.WIRED
        else -> OutputType.SPEAKER
    }

    companion object {
        /** 4 = Bluetooth, 3 = USB, 2 = wired, 0 = speaker/other. */
        fun rankType(t: Int): Int = when (t) {
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, TYPE_BLE_HEADSET, TYPE_BLE_SPEAKER, TYPE_HEARING_AID -> 4
            TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_ACCESSORY -> 3
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_LINE_ANALOG -> 2
            else -> 0
        }

        // Literal values so they compile/run on every API level.
        private const val TYPE_USB_HEADSET = 22
        private const val TYPE_HEARING_AID = 23
        private const val TYPE_BLE_HEADSET = 26
        private const val TYPE_BLE_SPEAKER = 27
    }
}
