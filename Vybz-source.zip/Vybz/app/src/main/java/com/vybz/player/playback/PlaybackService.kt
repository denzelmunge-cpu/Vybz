package com.vybz.player.playback

import android.app.PendingIntent
import android.content.Intent
import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.metadata.MetadataRenderer
import androidx.media3.common.MimeTypes
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.vybz.player.R
import com.vybz.player.audio.AudioEngine
import com.vybz.player.audio.HiResAudioSink
import com.vybz.player.data.AppSettings
import com.vybz.player.data.ListeningStats
import com.vybz.player.data.SleepTimer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        AppSettings.init(this)
        AudioEngine.init(this)
        ListeningStats.init(this)

        // Audio-only renderer chain. Decoders output 32-bit float where the phone supports it,
        // and the Vybz Hi-Res engine processes / resamples everything before the AudioTrack.
        val floatSink = DefaultAudioSink.Builder(this)
            .setEnableFloatOutput(true)
            .setEnableAudioTrackPlaybackParams(true) // speed & pitch on the float path
            .build()
        val audioSink = HiResAudioSink(this, floatSink)
        val renderersFactory = RenderersFactory { handler, _, audioListener, _, metadataOutput ->
            arrayOf<Renderer>(
                MediaCodecAudioRenderer(this, MediaCodecSelector.DEFAULT, handler, audioListener, audioSink),
                // Live radio "now playing" (ICY / HLS ID3 song titles)
                MetadataRenderer(metadataOutput, handler.looper),
            )
        }

        player = ExoPlayer.Builder(this, renderersFactory)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true) // pause when earphones are unplugged / BT drops
            .setWakeMode(C.WAKE_MODE_NETWORK) // keeps Wi-Fi awake for radio streams
            .build()

        val launch = packageManager.getLaunchIntentForPackage(packageName) ?: Intent()
        val pi = PendingIntent.getActivity(
            this, 0, launch,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        session = MediaSession.Builder(this, player)
            .setSessionActivity(pi)
            .setCallback(SessionCallback())
            .build()

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this).build().also {
                it.setSmallIcon(R.drawable.ic_notification)
            }
        )

        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                AudioEngine.sourceLossy = isLossy(mediaItem)
                mediaItem?.mediaId?.takeIf { it.startsWith("radio:") }?.let {
                    com.vybz.player.data.RadioRepository.reportPlay(it.removePrefix("radio:"))
                }
                saveQueue()
                if (mediaItem != null && reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) {
                    ListeningStats.recordPlay(mediaItem.mediaId)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) = saveQueue()

            // A damaged or unsupported file: skip it instead of stopping the music.
            override fun onPlayerError(error: PlaybackException) {
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }
            }
        })

        // Apply playback settings live; Hi-Res rate changes rebuild the audio output.
        scope.launch {
            var lastHq: Pair<Boolean, Int>? = null
            AppSettings.state.collect { s ->
                player.playbackParameters = PlaybackParameters(s.speed, s.pitch)
                val hq = s.hqEnabled to s.hqRate
                if (lastHq != null && lastHq != hq) reconfigureAudio()
                lastHq = hq
            }
        }

        // New output plugged in (USB DAC, Bluetooth…) → pick the best rate for it.
        scope.launch {
            var first = true
            AudioEngine.state.map { it.output.type }.distinctUntilChanged().collect {
                val s = AppSettings.current
                if (!first && s.hqEnabled && s.hqRate == 0) reconfigureAudio()
                first = false
            }
        }

        // Sleep timer.
        scope.launch {
            SleepTimer.endAt.collectLatest { end ->
                if (end > 0L) {
                    val wait = end - SystemClock.elapsedRealtime()
                    if (wait > 0) delay(wait)
                    player.pause()
                    SleepTimer.cancel()
                }
            }
        }

        // Periodically remember the position for "resume where you left off".
        scope.launch {
            while (isActive) {
                delay(15_000)
                if (player.isPlaying) saveQueue()
            }
        }
    }

    /** Re-creates the audio output at the same position so new Hi-Res settings take effect. */
    private fun reconfigureAudio() {
        if (player.mediaItemCount == 0) return
        val items = (0 until player.mediaItemCount).map { player.getMediaItemAt(it) }
        val index = player.currentMediaItemIndex
        val position = player.currentPosition
        val playWhenReady = player.playWhenReady
        player.setMediaItems(items, index, position)
        player.prepare()
        player.playWhenReady = playWhenReady
    }

    private fun isLossy(item: MediaItem?): Boolean {
        val uri = item?.localConfiguration?.uri ?: item?.requestMetadata?.mediaUri ?: return true
        val mime = (try { contentResolver.getType(uri) } catch (e: Exception) { null }).orEmpty().lowercase()
        val ext = uri.lastPathSegment.orEmpty().substringAfterLast('.', "").lowercase()
        val lossless = listOf("flac", "wav", "aiff", "alac", "ape", "wavpack", "dsd")
        return lossless.none { mime.contains(it) } && ext !in listOf("flac", "wav", "aif", "aiff", "alac", "ape", "wv", "dsf", "dff")
    }

    private fun saveQueue() {
        val ids = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).mediaId }
        AppSettings.saveQueue(ids, player.currentMediaItemIndex, player.currentPosition)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        saveQueue()
        scope.cancel()
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    /** Re-attaches the playable URI to items sent from the UI (URIs are not sent over IPC). */
    private inner class SessionCallback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { item ->
                val uri = item.requestMetadata.mediaUri ?: item.localConfiguration?.uri
                if (uri == null) {
                    item
                } else {
                    val b = item.buildUpon().setUri(uri)
                    val hls = item.requestMetadata.extras?.getBoolean("hls") == true ||
                        uri.toString().contains(".m3u8", ignoreCase = true)
                    if (hls) b.setMimeType(MimeTypes.APPLICATION_M3U8)
                    b.build()
                }
            }.toMutableList()
            return Futures.immediateFuture(resolved)
        }
    }
}
