package com.vybz.player.data

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Settings(
    val dynamicColor: Boolean = true,
    val pureBlack: Boolean = true,
    /** 0 = Vybz Neon, 1 = Kenyan Safari */
    val theme: Int = 0,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val skipSilence: Boolean = false,
    val minDurationSec: Int = 30,
    val onlineEnabled: Boolean = true,
    val wifiOnly: Boolean = false,
    val autoLyrics: Boolean = true,
    val autoArtwork: Boolean = true,
    /** Set once the user has answered the "use the internet?" consent prompt. */
    val consentAsked: Boolean = false,
    /** Hi-Res engine: resample to the best output rate (otherwise keep the file's rate). */
    val hqEnabled: Boolean = true,
    /** 0 = Auto (best for device), 1 = Original, or a fixed rate such as 96000. */
    val hqRate: Int = 0,
    /** 0 = Off, 1 = Auto (compressed files only), 2 = Always. */
    val restoreMode: Int = 1,
    val restoreAmount: Float = 0.35f,
    /** TV: ask before streaming video on mobile data. */
    val tvWifiOnly: Boolean = true,
    /** TV picture: 0 = Auto, 1 = Data saver, 2 = Best (HD) */
    val tvQuality: Int = 0,
)

object AppSettings {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(Settings())
    val state: StateFlow<Settings> = _state.asStateFlow()
    val current: Settings get() = _state.value

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.getSharedPreferences("vybz_settings", Context.MODE_PRIVATE)
        _state.value = Settings(
            dynamicColor = prefs.getBoolean("dynamicColor", true),
            pureBlack = prefs.getBoolean("pureBlack", true),
            theme = prefs.getInt("theme", 0),
            speed = prefs.getFloat("speed", 1f),
            pitch = prefs.getFloat("pitch", 1f),
            skipSilence = prefs.getBoolean("skipSilence", false),
            minDurationSec = prefs.getInt("minDurationSec", 30),
            onlineEnabled = prefs.getBoolean("onlineEnabled", true),
            wifiOnly = prefs.getBoolean("wifiOnly", false),
            autoLyrics = prefs.getBoolean("autoLyrics", true),
            autoArtwork = prefs.getBoolean("autoArtwork", true),
            consentAsked = prefs.getBoolean("consentAsked", false),
            hqEnabled = prefs.getBoolean("hqEnabled", true),
            hqRate = prefs.getInt("hqRate", 0),
            restoreMode = prefs.getInt("restoreMode", 1),
            restoreAmount = prefs.getFloat("restoreAmount", 0.35f),
            tvWifiOnly = prefs.getBoolean("tvWifiOnly", true),
            tvQuality = prefs.getInt("tvQuality", 0),
        )
    }

    fun update(transform: (Settings) -> Settings) {
        val s = transform(_state.value)
        _state.value = s
        prefs.edit()
            .putBoolean("dynamicColor", s.dynamicColor)
            .putBoolean("pureBlack", s.pureBlack)
            .putInt("theme", s.theme)
            .putFloat("speed", s.speed)
            .putFloat("pitch", s.pitch)
            .putBoolean("skipSilence", s.skipSilence)
            .putInt("minDurationSec", s.minDurationSec)
            .putBoolean("onlineEnabled", s.onlineEnabled)
            .putBoolean("wifiOnly", s.wifiOnly)
            .putBoolean("autoLyrics", s.autoLyrics)
            .putBoolean("autoArtwork", s.autoArtwork)
            .putBoolean("consentAsked", s.consentAsked)
            .putBoolean("hqEnabled", s.hqEnabled)
            .putInt("hqRate", s.hqRate)
            .putInt("restoreMode", s.restoreMode)
            .putFloat("restoreAmount", s.restoreAmount)
            .putBoolean("tvWifiOnly", s.tvWifiOnly)
            .putInt("tvQuality", s.tvQuality)
            .apply()
    }

    // ---- Last queue (resume where you left off) ----
    fun saveQueue(ids: List<String>, index: Int, positionMs: Long) {
        if (!::prefs.isInitialized) return
        prefs.edit()
            .putString("queue", ids.joinToString(","))
            .putInt("queueIndex", index)
            .putLong("queuePos", positionMs)
            .apply()
    }

    fun loadQueue(): Triple<List<String>, Int, Long> {
        val ids = prefs.getString("queue", "")?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
        return Triple(ids, prefs.getInt("queueIndex", 0), prefs.getLong("queuePos", 0L))
    }
}

/** Private, on-device listening stats. Nothing leaves the phone. */
object ListeningStats {
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.getSharedPreferences("vybz_stats", Context.MODE_PRIVATE)
    }

    fun recordPlay(key: String) {
        if (!::prefs.isInitialized || key.isBlank()) return
        prefs.edit()
            .putInt("p_$key", prefs.getInt("p_$key", 0) + 1)
            .putInt("total", prefs.getInt("total", 0) + 1)
            .apply()
    }

    fun totalPlays(): Int = if (::prefs.isInitialized) prefs.getInt("total", 0) else 0

    /** Song keys with play counts, most played first. */
    fun top(n: Int): List<Pair<String, Int>> {
        if (!::prefs.isInitialized) return emptyList()
        return prefs.all.entries
            .filter { it.key.startsWith("p_") && it.value is Int }
            .map { it.key.removePrefix("p_") to (it.value as Int) }
            .sortedByDescending { it.second }
            .take(n)
    }

    fun clear() {
        if (::prefs.isInitialized) prefs.edit().clear().apply()
    }
}

/** Sleep timer shared by UI and service. endAt = elapsedRealtime deadline, 0 = off. */
object SleepTimer {
    private val _endAt = MutableStateFlow(0L)
    val endAt: StateFlow<Long> = _endAt.asStateFlow()

    fun start(minutes: Int) {
        _endAt.value = SystemClock.elapsedRealtime() + minutes * 60_000L
    }

    fun cancel() {
        _endAt.value = 0L
    }
}
