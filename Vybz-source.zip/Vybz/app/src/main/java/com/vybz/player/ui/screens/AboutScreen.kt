@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vybz.player.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vybz.player.BuildConfig
import com.vybz.player.R
import com.vybz.player.data.ListeningStats
import com.vybz.player.ui.DocKind
import com.vybz.player.ui.MainViewModel
import com.vybz.player.ui.Screen

private const val EFFECTIVE_DATE = "12 October 2026"

fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(context, "No browser app found to open this link.", Toast.LENGTH_SHORT).show()
    }
}

fun shareText(context: Context, text: String) {
    try {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        context.startActivity(Intent.createChooser(send, "Share via").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(context, "No app available to share with.", Toast.LENGTH_SHORT).show()
    }
}

const val SHARE_APP_TEXT = "I'm listening with Vybz — a music & live radio player with a 10-band EQ, synced lyrics and sound tuned for earbuds, Bluetooth, USB-C and 3.5mm earphones."

@Composable
fun AboutScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val lib by vm.library.collectAsState()
    var statsVersion by remember { mutableIntStateOf(0) }
    val total = remember(statsVersion) { ListeningStats.totalPlays() }
    val top = remember(statsVersion, lib) {
        ListeningStats.top(5).mapNotNull { (key, count) -> lib.byKey[key]?.let { it to count } }
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("About Vybz") },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 16.dp).padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painterResource(R.drawable.vybz_logo),
                contentDescription = "Vybz logo",
                modifier = Modifier.widthIn(max = 220.dp).fillMaxWidth(0.6f).padding(top = 8.dp)
            )
            Text(
                "Version ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
            Text(
                "Your music, tuned for whatever you plug in.",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    val songs = vm.library.value.songs
                    vm.back()
                    if (songs.isNotEmpty()) { vm.playSongs(songs, shuffle = true); vm.nowPlayingOpen = true }
                }) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Start listening")
                }
                OutlinedButton(onClick = { shareText(context, SHARE_APP_TEXT) }) {
                    Icon(Icons.Rounded.Share, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Share Vybz")
                }
            }

            // Private stats
            Card(
                Modifier.fillMaxWidth().padding(top = 22.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Your listening", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Counted on this phone only. Nothing is uploaded.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "$total plays",
                        style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    top.forEachIndexed { i, (song, count) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(22.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Column(Modifier.weight(1f)) {
                                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("$count×", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (total > 0) {
                        TextButton(onClick = { ListeningStats.clear(); statsVersion++ }) { Text("Clear stats") }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            DocKind.values().forEach { kind ->
                LinkRow(kind.title) { vm.navigate(Screen.Doc(kind)) }
            }

            // Credits
            Text(
                "CREDITS",
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 4.dp)
            )
            Text(
                com.vybz.player.DEVELOPER_CREDIT,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            )
            HorizontalDivider()

            Text(
                "ONLINE SOURCES",
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 4.dp)
            )
            LinkRow("Lyrics · LRCLIB") { openUrl(context, "https://lrclib.net") }
            LinkRow("Artwork & genre · iTunes Search") { openUrl(context, "https://performance-partners.apple.com/search-api") }
            LinkRow("Artist bios · Wikipedia") { openUrl(context, "https://www.wikipedia.org") }
        }
    }
}

@Composable
private fun LinkRow(title: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    HorizontalDivider()
}

// ------------------------------------------------------------------ Documents

@Composable
fun DocScreen(vm: MainViewModel, kind: DocKind) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(kind.title) },
            navigationIcon = { IconButton(onClick = { vm.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 18.dp).padding(bottom = 32.dp)
        ) {
            when (kind) {
                DocKind.PRIVACY -> Sections(privacySections, "Effective $EFFECTIVE_DATE")
                DocKind.TERMS -> Sections(termsSections, "Effective $EFFECTIVE_DATE")
                DocKind.FAQ -> faq.forEach { (q, a) -> FaqItem(q, a) }
                DocKind.CHECKLIST -> Checklist()
            }
        }
    }
}

@Composable
private fun Sections(sections: List<Pair<String, String>>, subtitle: String) {
    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    sections.forEach { (h, body) ->
        Text(h, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
        Text(body, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun FaqItem(q: String, a: String) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(q, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, if (open) "Collapse" else "Expand")
        }
        if (open) {
            Text(a, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp))
        }
    }
    HorizontalDivider()
}

private enum class Status(val label: String, val color: Color) {
    DONE("Done", Color(0xFF3DDC97)),
    EQUIVALENT("App equivalent", Color(0xFF3DDCFF)),
    WEB_ONLY("Web only", Color(0xFFB0A8C8)),
}

private data class CheckItem(val title: String, val status: Status, val how: String)

private val checklist = listOf(
    CheckItem("Privacy policy", Status.DONE, "About → Privacy policy. States that your music never leaves the phone and lists exactly what is sent when online features are on."),
    CheckItem("Terms page", Status.DONE, "About → Terms of use."),
    CheckItem("Clear call to action", Status.DONE, "Every first screen leads with one action: Allow music access, Shuffle all, Rescan when the library is empty, and Start listening in About."),
    CheckItem("FAQ", Status.DONE, "About → FAQ, covering sound quality, Bluetooth codecs, lyrics, offline use and missing songs."),
    CheckItem("Robots.txt", Status.WEB_ONLY, "Websites only. Vybz has no web pages for search engines to crawl and exposes nothing to them."),
    CheckItem("Sitemap.xml", Status.EQUIVALENT, "Websites only. The app equivalent is shallow, predictable navigation: Library → Now Playing → Sound / Settings → About, every screen within two taps and Back always works."),
    CheckItem("Custom 404 page", Status.EQUIVALENT, "Friendly empty and error states: no music found (with Rescan), no search results, no lyrics found (with Retry and Search), and unplayable files are skipped with a message."),
    CheckItem("Image alt text", Status.DONE, "Album art, the logo and every icon button carry descriptions for TalkBack."),
    CheckItem("Analytics", Status.DONE, "Private, on-device listening stats in About (plays and top songs). No third-party analytics, tracking or ads."),
    CheckItem("Meta titles", Status.EQUIVALENT, "App name on the launcher, a clear title on every screen, and song title and artist on the notification and lock screen."),
    CheckItem("Meta descriptions", Status.EQUIVALENT, "Store listing short and full descriptions are included with the source (STORE_LISTING.md)."),
    CheckItem("Social sharing previews", Status.EQUIVALENT, "Share the song you're playing from Now Playing, or share Vybz from About, with a ready-written message."),
    CheckItem("Favicon", Status.EQUIVALENT, "The Vybz logo is the launcher icon: adaptive, round, legacy and Android 13 themed (monochrome) versions."),
    CheckItem("Canonical URLs", Status.WEB_ONLY, "Websites only. In the app, each song has one stable ID from the phone's media library, so the queue and stats never double-count."),
    CheckItem("Cookie consent", Status.EQUIVALENT, "Vybz uses no cookies. On first launch it asks before using the internet (Allow online / Stay offline); change it any time in Settings."),
    CheckItem("Mobile layout", Status.DONE, "Built for phones: edge-to-edge, adapts from small to large screens, system bars respected."),
    CheckItem("Accessibility", Status.DONE, "TalkBack labels, 48 dp touch targets, EQ sliders announce their band and level, system font size respected, high-contrast dark theme."),
    CheckItem("Test every form", Status.DONE, "Lyrics search and preset name fields validate input; actions stay disabled until required fields are filled."),
    CheckItem("Check broken links", Status.DONE, "All in-app links (LRCLIB, iTunes, Wikipedia) are checked and open safely; if no browser is installed Vybz shows a message instead of crashing."),
    CheckItem("Licensed content only", Status.DONE, "TV lists only broadcasters' free, official streams; channels that stream on YouTube open in the YouTube app."),
    CheckItem("Optimise loading speed", Status.DONE, "Library scanned in the background, artwork cached in memory, sorting and search memoised, lazy lists, and no network needed to start playing. The Hi-Res engine runs in real time with no pre-conversion wait."),
)

@Composable
private fun Checklist() {
    val done = checklist.count { it.status != Status.WEB_ONLY }
    Text(
        "$done of ${checklist.size} items apply to an Android app and are covered. The rest are website-only.",
        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
    )
    checklist.forEachIndexed { i, item ->
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
            Text(
                "${i + 1}.", Modifier.width(32.dp),
                style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Surface(shape = RoundedCornerShape(50), color = item.status.color.copy(alpha = 0.16f)) {
                        Text(
                            item.status.label, color = item.status.color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                        )
                    }
                }
                Text(item.how, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp))
            }
        }
        HorizontalDivider()
    }
    Box(Modifier.height(8.dp))
}

// ------------------------------------------------------------------ Texts

private val privacySections = listOf(
    "Summary" to "Vybz plays the music stored on your phone. Your music files, playlists, settings and listening stats stay on your device. Vybz has no accounts, no ads and no analytics or tracking services.",
    "What Vybz reads on your phone" to "With your permission Vybz reads your audio library (titles, artists, albums, durations, artwork and file locations) so it can list and play your music. This information is only used inside the app.",
    "Online features (optional)" to "If you choose Allow online, Vybz sends the song title, artist name and duration to look up lyrics (LRCLIB), cover art, genre and release year (Apple iTunes Search), and artist biographies (Wikipedia). No audio, no file contents and no personal identifiers are sent. Those services receive your IP address as part of any normal internet request and handle it under their own privacy policies. You can turn online features off, or limit them to Wi-Fi, in Settings at any time.",
    "Live radio" to "When you use the Radio tab, Vybz sends your search words and chosen country, language and genre filters to the Radio Browser directory (radio-browser.info) and tells it which station you played, which helps rank popular stations. Playing a station connects your phone directly to that station's stream server. Favourite stations are stored only on your phone.",
    "Live TV" to "Channels marked ▶ Vybz stream directly from the broadcaster's own servers to your phone. Channels marked YouTube open in the YouTube app, where YouTube's privacy policy applies. Vybz does not record what you watch beyond the favourites you save on your phone.",
    "Data stored on your phone" to "Lyrics, artwork and information that Vybz downloads are saved in the app's private storage so they work offline. Settings → Clear downloaded lyrics & info deletes them. Listening stats can be cleared in About. Uninstalling Vybz removes all of its data.",
    "Permissions" to "Music & audio (or Storage on older Android): to find your songs. Notifications: to show playback controls. Internet: only for the optional online features. Foreground service: to keep music playing with the screen off.",
    "Children" to "Vybz does not knowingly collect personal information from anyone, including children.",
    "Changes" to "If this policy changes, the new version will appear in the app with a new effective date.",
)

private val termsSections = listOf(
    "Using Vybz" to "Vybz is a music player for audio files you already have on your device. You are responsible for having the right to play the music you load into it.",
    "Online content" to "Lyrics, artwork and artist information come from third-party services (LRCLIB, Apple iTunes Search and Wikipedia). Vybz does not own that content and cannot guarantee it is accurate or always available. Each service's own terms apply to its content.",
    "Hearing safety" to "Sound enhancements such as bass boost and EQ boosts can make audio louder. Start at a low volume and avoid listening at high volume for long periods.",
    "No warranty" to "Vybz is provided as is, without warranties of any kind. The developer is not liable for any loss or damage arising from use of the app, to the extent permitted by law.",
    "Changes" to "These terms may be updated with new versions of the app. Continuing to use Vybz after an update means you accept the updated terms.",
)

private val faq = listOf(
    "What does the Hi-Res engine do?" to "Fully offline, Vybz decodes songs in 32-bit float, processes them in 64-bit, resamples them with a precision filter to the best rate for your output (your phone's native rate, or up to 192 kHz on a USB DAC; on Android 14+ it also switches the USB output to hi-res) and plays them as 32-bit float. Hi-Res Restore adds gentle treble harmonics to compressed files. It can't recreate detail that was never in the file, but it removes every quality loss after the file.",
    "How do I get the best sound?" to "Open Sound, pick the tuning for your gear (for example Wired EarPods or TWS Earbuds), then a music preset. Keep the limiter and auto headroom on and use the preamp rather than large EQ boosts.",
    "Why does my Bluetooth sound different from wired?" to "Vybz keeps a separate sound profile for each output and switches automatically. The Bluetooth codec itself (LDAC, aptX, AAC, SBC) is chosen by Android: Settings → Developer options → Bluetooth audio codec.",
    "Does Vybz work without internet?" to "Yes. Playback, EQ and your library are fully offline. Lyrics, art and bios you've already viewed are saved for offline use.",
    "How does TV work?" to "Open the TV tab. Channels marked ▶ Vybz play inside the app with picture-in-picture, full screen and a quality choice (Auto, Data saver, Best). Kenyan channels such as Citizen, NTV and KTN stream officially on YouTube, so they open the live stream in the YouTube app. Vybz only lists free, official streams.",
    "A TV channel won't play" to "Broadcasters sometimes move or pause their streams. Tap Try again later, or add the channel's current official link with Add a channel by link.",
    "How do I find radio stations?" to "Open the Radio tab → Discover. Kenyan stations are shown first; tap Country, Language or Genre to change the filters, or search by name. Tap the heart to save a station to Favourites. You can also add any station by its stream link.",
    "A radio station won't play" to "Some stations change their stream links or only stream inside their own app. Try again later, pick another station, or add the station's current link with Add a station by link. Radio needs an internet connection (about 60 MB per hour).",
    "Why are there no lyrics for a song?" to "Lyrics are matched by title and artist. If tags are messy, open Lyrics → Search… and type the correct title and artist. You can also place a .lrc file with the same name next to the song.",
    "Some songs are missing" to "Vybz hides very short tracks (ringtones, voice notes). Lower the limit in Settings → Library, then tap Rescan music. Also check the files are music files your phone recognises.",
    "Which formats are supported?" to "MP3, AAC/M4A, FLAC, OGG/Vorbis, Opus, WAV and AMR, using your phone's decoders.",
    "Do USB-C earphones work?" to "Yes. Digital USB-C earphones and DACs are detected as USB-C and get their own profile; Vybz shows the device name and whether it supports Hi-Res sample rates.",
    "Will my settings be kept when I update?" to "Yes. Every Vybz build is signed with the same key, so new versions install over the old one and keep your settings and stats.",
)
