package com.vybz.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Collections

/** Loads album art: embedded tags → system thumbnail → album art → cached online cover. */
object ArtworkLoader {

    private val cache = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = Collections.synchronizedSet(HashSet<String>())

    fun cached(song: Song, size: Int): Bitmap? = cache.get("${song.key}@$size")

    fun invalidate(song: Song) {
        missing.removeAll { it.startsWith(song.key + "@") }
        cache.snapshot().keys.filter { it.startsWith(song.key + "@") }.forEach { cache.remove(it) }
    }

    suspend fun load(context: Context, song: Song, size: Int): Bitmap? = withContext(Dispatchers.IO) {
        val key = "${song.key}@$size"
        cache.get(key)?.let { return@withContext it }
        if (missing.contains(key)) return@withContext null
        val bmp = loadUncached(context, song, size)
        if (bmp != null) cache.put(key, bmp) else missing.add(key)
        bmp
    }

    private fun loadUncached(context: Context, song: Song, size: Int): Bitmap? {
        if (song.isRadio) return radioLogo(context, song, size)
        // 1. System thumbnail (Android 10+) — fast and cached by the OS.
        if (Build.VERSION.SDK_INT >= 29 && song.id >= 0) {
            try {
                return context.contentResolver.loadThumbnail(song.uri, Size(size, size), null)
            } catch (e: Exception) { /* fall through */ }
        }
        // 2. Embedded picture in the file tags.
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, song.uri)
                val bytes = r.embeddedPicture
                if (bytes != null) decode(bytes, size)?.let { return it }
            } finally {
                try { r.release() } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
        // 3. Legacy album-art provider.
        if (song.albumId > 0 && Build.VERSION.SDK_INT < 29) {
            try {
                context.contentResolver.openInputStream(song.albumArtUri)?.use { s ->
                    decode(s.readBytes(), size)?.let { return it }
                }
            } catch (e: Exception) { }
        }
        // 4. Cover downloaded earlier from the internet.
        try {
            val f = OnlineRepository.artFile(context, song)
            if (f.exists()) decode(f.readBytes(), size)?.let { return it }
        } catch (e: Exception) { }
        return null
    }

    /** Station logo from Radio Browser, cached on the phone after the first download. */
    private fun radioLogo(context: Context, song: Song, size: Int): Bitmap? {
        val url = song.favicon
        if (!url.startsWith("http")) return null
        return try {
            val dir = java.io.File(context.filesDir, "online/radio").apply { mkdirs() }
            val f = java.io.File(dir, url.hashCode().toUInt().toString() + ".img")
            val bytes = if (f.exists() && f.length() > 0) f.readBytes()
            else OnlineRepository.httpGetBytes(url)?.also { if (it.size < 2_000_000) f.writeBytes(it) }
            bytes?.let { decode(it, size) }
        } catch (e: Exception) {
            null
        }
    }

    private fun decode(bytes: ByteArray, size: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= size && bounds.outHeight / (sample * 2) >= size) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    /** Average colour of the artwork, used for the Now Playing backdrop. */
    fun dominantColor(bmp: Bitmap): Int {
        return try {
            val s = Bitmap.createScaledBitmap(bmp, 1, 1, true)
            s.getPixel(0, 0)
        } catch (e: Exception) {
            0xFF2A1B5C.toInt()
        }
    }
}
