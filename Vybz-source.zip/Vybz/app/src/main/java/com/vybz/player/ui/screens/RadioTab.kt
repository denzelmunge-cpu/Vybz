@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vybz.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.vybz.player.data.RadioFilterOption
import com.vybz.player.data.RadioFilters
import com.vybz.player.data.RadioRepository
import com.vybz.player.data.RadioStation
import com.vybz.player.ui.MainViewModel
import com.vybz.player.ui.components.Artwork
import kotlinx.coroutines.launch

private enum class FilterKind(val title: String) { COUNTRY("Country"), LANGUAGE("Language"), GENRE("Genre") }

@Composable
fun RadioTab(vm: MainViewModel) {
    var section by rememberSaveable { mutableIntStateOf(0) } // 0 = Discover, 1 = Favourites
    val favourites by RadioRepository.favourites.collectAsState()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = section == 0, onClick = { section = 0 }, label = { Text("Discover") },
                leadingIcon = { Icon(Icons.Rounded.Search, null, Modifier.size(18.dp)) })
            FilterChip(selected = section == 1, onClick = { section = 1 }, label = { Text("Favourites · ${favourites.size}") },
                leadingIcon = { Icon(Icons.Rounded.Favorite, null, Modifier.size(18.dp)) })
        }
        if (section == 0) DiscoverSection(vm) else FavouritesSection(vm, favourites) { section = 0 }
    }
}

@Composable
private fun DiscoverSection(vm: MainViewModel) {
    val filters by RadioRepository.filters.collectAsState()
    val player by vm.player.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf("") }
    val results = remember { mutableStateListOf<RadioStation>() }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var endReached by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf<FilterKind?>(null) }
    val scope = rememberCoroutineScope()

    fun load(reset: Boolean) {
        if (loading) return
        loading = true
        failed = false
        scope.launch {
            val offset = if (reset) 0 else results.size
            val page = RadioRepository.search(submitted, filters, offset)
            if (page == null) {
                failed = true
            } else {
                if (reset) results.clear()
                results.addAll(page.filter { s -> results.none { it.uuid == s.uuid } })
                endReached = page.size < 40
            }
            loading = false
        }
    }

    LaunchedEffect(filters, submitted) { load(reset = true) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search stations by name") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = ""; submitted = "" }) {
                        Icon(Icons.Rounded.Close, "Clear search")
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { submitted = query.trim() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filters.countryCode.isNotBlank(),
                    onClick = { picker = FilterKind.COUNTRY },
                    label = { Text(if (filters.countryCode.isBlank()) "Any country" else filters.countryName) }
                )
                FilterChip(
                    selected = filters.language.isNotBlank(),
                    onClick = { picker = FilterKind.LANGUAGE },
                    label = { Text(filters.language.ifBlank { "Any language" }.replaceFirstChar { it.uppercase() }) }
                )
                FilterChip(
                    selected = filters.tag.isNotBlank(),
                    onClick = { picker = FilterKind.GENRE },
                    label = { Text(filters.tag.ifBlank { "Any genre" }.replaceFirstChar { it.uppercase() }) }
                )
                if (filters.language.isNotBlank() || filters.tag.isNotBlank() || filters.countryCode != "KE") {
                    TextButton(onClick = { RadioRepository.setFilters(RadioFilters()) }) { Text("Reset") }
                }
            }
            Text(
                "Live radio uses the internet (about 60 MB per hour). Directory: radio-browser.info",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        itemsIndexed(results, key = { _, s -> s.uuid }) { i, station ->
            StationRow(station, isCurrent = player.song?.radioId == station.uuid) {
                vm.playStations(results.toList(), i)
            }
        }

        item {
            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                when {
                    loading -> CircularProgressIndicator()
                    failed -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Couldn't reach the radio directory. Check your internet connection.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { load(reset = results.isEmpty()) }) { Text("Try again") }
                    }
                    results.isEmpty() -> Text("No stations match these filters. Try another genre or language.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    !endReached -> OutlinedButton(onClick = { load(reset = false) }) { Text("Load more stations") }
                }
            }
        }
    }

    picker?.let { kind ->
        FilterPickerDialog(kind, onDismiss = { picker = null }) { option ->
            val f = RadioRepository.filters.value
            RadioRepository.setFilters(
                when (kind) {
                    FilterKind.COUNTRY -> f.copy(countryCode = option?.value ?: "", countryName = option?.label ?: "")
                    FilterKind.LANGUAGE -> f.copy(language = option?.value ?: "")
                    FilterKind.GENRE -> f.copy(tag = option?.value ?: "")
                }
            )
            picker = null
        }
    }
}

@Composable
private fun FilterPickerDialog(kind: FilterKind, onDismiss: () -> Unit, onPick: (RadioFilterOption?) -> Unit) {
    var options by remember { mutableStateOf<List<RadioFilterOption>?>(null) }
    var text by remember { mutableStateOf("") }
    LaunchedEffect(kind) {
        options = when (kind) {
            FilterKind.COUNTRY -> RadioRepository.countries()
            FilterKind.LANGUAGE -> RadioRepository.languages()
            FilterKind.GENRE -> RadioRepository.genres()
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose ${kind.title.lowercase()}") },
        text = {
            Column {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    placeholder = { Text("Type to filter") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                val list = options
                when {
                    list == null -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    list.isEmpty() -> Text("Couldn't load the list. Check your internet connection.")
                    else -> {
                        val shown = list.filter { it.label.contains(text.trim(), ignoreCase = true) }.take(150)
                        LazyColumn(Modifier.heightIn(max = 380.dp)) {
                            item {
                                Text(
                                    "Any ${kind.title.lowercase()}",
                                    Modifier.fillMaxWidth().clickable { onPick(null) }.padding(vertical = 12.dp),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                HorizontalDivider()
                            }
                            items(shown, key = { it.value + it.label }) { o ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { onPick(o) }.padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(o.label, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${o.count}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun FavouritesSection(vm: MainViewModel, favourites: List<RadioStation>, onDiscover: () -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    val player by vm.player.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        if (favourites.isEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Rounded.Radio, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No favourite stations yet", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Tap the heart on any station in Discover to keep it here.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onDiscover) { Text("Find stations") }
                }
            }
        } else {
            itemsIndexed(favourites, key = { _, s -> s.uuid }) { i, station ->
                StationRow(station, isCurrent = player.song?.radioId == station.uuid) {
                    vm.playStations(favourites, i)
                }
            }
        }
        item {
            TextButton(onClick = { showAdd = true }, modifier = Modifier.padding(horizontal = 8.dp)) {
                Icon(Icons.Rounded.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Add a station by link")
            }
        }
    }
    if (showAdd) AddStationDialog { showAdd = false }
}

@Composable
private fun AddStationDialog(onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val valid = url.trim().let { it.startsWith("http://") || it.startsWith("https://") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a station") },
        text = {
            Column {
                OutlinedTextField(name, { name = it.take(40) }, label = { Text("Station name") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    url, { url = it }, label = { Text("Stream link (http/https)") }, singleLine = true,
                    isError = url.isNotBlank() && !valid,
                    supportingText = { Text("MP3, AAC or .m3u8 stream link") }
                )
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { RadioRepository.addCustom(name.trim(), url.trim()); onDismiss() }) {
                Text("Save")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun StationRow(station: RadioStation, isCurrent: Boolean, onClick: () -> Unit) {
    val favourites by RadioRepository.favourites.collectAsState()
    val fav = favourites.any { it.uuid == station.uuid }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(station.toSong(), Modifier.size(50.dp), sizePx = 150, corner = 10.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                station.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                station.details.ifBlank { "Live radio" }, style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = { RadioRepository.toggleFavourite(station) }) {
            Icon(
                if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                if (fav) "Remove from favourites" else "Add to favourites",
                tint = if (fav) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
