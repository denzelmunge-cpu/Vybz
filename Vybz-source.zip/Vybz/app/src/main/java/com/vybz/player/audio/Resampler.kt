package com.vybz.player.audio

import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * High-precision sample-rate converter: Kaiser-windowed sinc, 64 taps, 512 interpolated
 * phases, 64-bit maths (~-100 dB stopband). Converts any rate to any rate, streaming.
 *
 * Used so Android's own (lower quality) mixer resampler is never needed: Vybz delivers audio
 * already at the device's native rate, or at a higher Hi-Res rate when the DAC supports it.
 */
class Resampler(private val channels: Int, inRate: Int, outRate: Int) {

    private val step = inRate.toDouble() / outRate        // input samples per output sample
    private val cutoff = minOf(1.0, outRate.toDouble() / inRate) * 0.955
    private val table: DoubleArray                         // (PHASES + 1) rows × TAPS2 columns

    private var buf = Array(channels) { DoubleArray(4096) }
    private var len = 0
    private var t = 0.0

    var out = Array(channels) { DoubleArray(4096) }
        private set

    init {
        table = DoubleArray((PHASES + 1) * TAPS2)
        for (p in 0..PHASES) {
            val frac = p.toDouble() / PHASES
            for (j in 0 until TAPS2) {
                val x = (j - (HALF - 1)) - frac          // distance from output instant
                table[p * TAPS2 + j] = kernel(x)
            }
        }
        reset()
    }

    private fun kernel(x: Double): Double {
        if (kotlin.math.abs(x) >= HALF) return 0.0
        val sinc = if (x == 0.0) 1.0 else sin(PI * cutoff * x) / (PI * cutoff * x)
        val r = x / HALF
        val w = bessel0(BETA * sqrt(1.0 - r * r)) / bessel0(BETA)
        return cutoff * sinc * w
    }

    private fun bessel0(x: Double): Double {
        var sum = 1.0
        var term = 1.0
        val q = x * x / 4.0
        var k = 1
        while (k < 60) {
            term *= q / (k.toDouble() * k)
            sum += term
            if (term < sum * 1e-16) break
            k++
        }
        return sum
    }

    fun reset() {
        for (c in 0 until channels) buf[c].fill(0.0)
        len = HALF - 1   // zero history so the first samples are centred
        t = (HALF - 1).toDouble()
    }

    /**
     * Feeds [n] new input frames (planar, one array per channel) and returns how many output
     * frames were written to [out].
     */
    fun process(input: Array<DoubleArray>, n: Int): Int {
        // make room
        if (len + n > buf[0].size) {
            val newSize = maxOf(buf[0].size * 2, len + n + 1024)
            buf = Array(channels) { c -> buf[c].copyOf(newSize) }
        }
        for (c in 0 until channels) System.arraycopy(input[c], 0, buf[c], len, n)
        len += n

        val maxOut = ((len - t) / step).toInt() + 4
        if (out[0].size < maxOut) out = Array(channels) { DoubleArray(maxOut + 1024) }

        var produced = 0
        while (true) {
            val i0 = floor(t).toInt()
            if (i0 + HALF >= len) break
            val frac = t - i0
            val pf = frac * PHASES
            val p = pf.toInt().coerceAtMost(PHASES - 1)
            val mix = pf - p
            val row0 = p * TAPS2
            val row1 = row0 + TAPS2
            val start = i0 - (HALF - 1)
            for (c in 0 until channels) {
                val b = buf[c]
                var acc = 0.0
                for (j in 0 until TAPS2) {
                    val h0 = table[row0 + j]
                    val h = h0 + (table[row1 + j] - h0) * mix
                    acc += b[start + j] * h
                }
                out[c][produced] = acc
            }
            produced++
            t += step
        }

        // discard input that is no longer needed
        val drop = floor(t).toInt() - (HALF - 1)
        if (drop > 0) {
            for (c in 0 until channels) System.arraycopy(buf[c], drop, buf[c], 0, len - drop)
            len -= drop
            t -= drop
        }
        return produced
    }

    companion object {
        private const val HALF = 32          // taps each side
        private const val TAPS2 = HALF * 2
        private const val PHASES = 512
        private const val BETA = 9.5
    }
}
