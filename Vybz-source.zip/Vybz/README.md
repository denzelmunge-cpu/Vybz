# Vybz — music, live radio & TV for Android

Version 1.5.0 · renamed to Vybz · live TV · Kenyan Safari theme · live radio (Radio Browser, 50,000+ stations) · offline Hi-Res engine · new Vybz logo · in-app Privacy policy, Terms, FAQ, Release checklist, private listening stats, first-run internet consent, song sharing.

Android 5.0+ (API 21) · Kotlin + Jetpack Compose · Media3 ExoPlayer · 64-bit DSP sound engine

## Features

**Live TV (new in 1.5)**
- TV tab: Kenyan, African and international channels, search, filters (Kenya / Africa / International / My channels), favourites
- Official free streams (Al Jazeera English, DW, France 24, NHK World, TRT World, CGTN) play inside Vybz with full screen, picture-in-picture and quality choice (Auto / Data saver / Best)
- Kenyan channels (Citizen, NTV, KTN, KBC, K24, TV47, Inooro, Ramogi) and others that stream on YouTube open their official live stream in the YouTube app
- Add a channel by link; mobile-data warning (Settings → TV); Vybz sound engine applies to TV sound

**Themes**
- Vybz Neon (violet & pink, optional Material You) or Kenyan Safari (savanna gold, sunset orange, acacia green on warm earth tones, with a Kenyan-flag stripe) — Settings → Appearance

**Live radio**
- Radio tab → Discover: search 50,000+ stations from the free Radio Browser directory; filter by country (Kenya by default), language and genre; load more results
- Favourites (heart on any station), add a station by its stream link
- Plays MP3/AAC/Icecast/Shoutcast and HLS (.m3u8) streams; shows the song on air when the station sends it; station logos
- EQ, per-device profiles and the Hi-Res engine apply to radio too; next/previous switch stations

**Hi-Res engine (fully offline, real time)**
- Decoders output 32-bit float (Android 7+), processing runs in 64-bit, output is 32-bit float — no 16-bit rounding anywhere
- Precision Kaiser-windowed sinc resampler (≈100–120 dB clean) converts every song to the best rate for the output: Auto (phone's native rate, or a USB DAC's highest rate up to 192 kHz), or fixed 48 / 96 / 192 kHz, or Original
- Android 14+: switches USB DACs/digital earphones to a hi-res output stream (preferred mixer attributes)
- Hi-Res Restore: gentle harmonic exciter that adds treble "air" to MP3/AAC files that lost their top end (Off / Compressed files / All files, adjustable)
- Live "16-bit / 44.1 kHz → 32-bit float / 96 kHz" readout on Now Playing and the Sound screen
- Honest note: no upscaler can recreate detail that isn't in the file; this removes every quality loss after the file

**Sound quality**
- Vybz sound engine running inside the player: 64-bit floating-point processing, 32-bit float output, peak limiter (no clipping), auto headroom
- 10-band graphic EQ (31 Hz – 16 kHz) with live response curve, 17 music presets (incl. Afrobeats, Gospel, Hip-Hop, Podcast) and custom presets
- Headphone/speaker tuning presets: Wired EarPods, TWS earbuds, IEMs, over-ear, phone speaker, BT speaker/car
- Bass shelf, treble/clarity shelf, preamp, stereo width, balance, headphone crossfeed, mono
- **Auto-switch per output**: separate sound profile for phone speaker, 3.5 mm, USB-C (DAC/digital earphones) and Bluetooth — Vybz detects the device and switches automatically. Shows device name and Hi-Res capability for USB DACs.
- Gapless playback, speed & pitch, skip silence, pause on unplug/Bluetooth disconnect, audio focus handling

**Library & playback**
- Songs / Albums / Artists / Folders, search, sorting, queue (play next, add, remove), shuffle, repeat
- Lock-screen / notification / Bluetooth / headset button controls
- Resume where you left off, sleep timer, "Open with Vybz" from file managers & WhatsApp

**Online (optional, cached for offline)**
- Time-synced lyrics (LRCLIB) with tap-to-seek, local `.lrc` support, manual lyrics search
- Missing cover art, genre and release year (iTunes Search)
- Artist bios (Wikipedia)
- Wi-Fi-only mode, cache clear. No accounts or API keys needed.

## Get the APK without a computer (GitHub, free)

1. Sign in at github.com (phone browser is fine) → **+ → New repository** → name it `vybz` → Create.
2. **Add file → Upload files** → upload `Vybz-source.zip` → **Commit changes**.
3. **Add file → Create new file** → name it `.github/workflows/build.yml` → paste the contents of `build.yml` → **Commit changes**.
4. Open the **Actions** tab and wait ~6–8 minutes for the green tick.
5. Open **Releases** (repo home page, right side / bottom on mobile) → download **Vybz.apk** → install
   (allow "Install unknown apps" for your browser when asked).

Every new commit builds a new release. All builds are signed with the same key, so new versions install over old ones.

## Build on a computer

Open the folder in Android Studio (Koala or newer) and press Run, or:

```
./gradlew assembleRelease
```

APK: `app/build/outputs/apk/release/app-release.apk`

## Notes

- The included signing key (`app/vybz-release.jks`, password `vybz2026`) is for personal installs. Create your own before publishing to the Play Store.
- Bluetooth codec (LDAC / aptX / AAC) is chosen by Android, not apps: Settings → Developer options → Bluetooth audio codec.
- Android 7.0 and older may fail to reach some lyric servers (old security certificates); playback is unaffected.
