# Vybz — store listing

**App name (title):** Vybz — Music, Radio & TV

**Short description (80 chars):**
Hi-Res music, 50,000+ radio stations & live TV, with a 10-band EQ.

**Full description:**
Vybz plays the music on your phone with sound tuned for whatever you plug in.

SOUND
• 64-bit sound engine with peak limiter and dithering for clean, distortion-free audio
• 10-band equaliser with live curve, 17 music presets and your own custom presets
• Tunings for wired EarPods, wireless earbuds, in-ear monitors, over-ear headphones and the phone speaker
• Bass, treble, preamp, stereo width, balance, headphone crossfeed and mono
• Separate sound for phone speaker, 3.5mm, USB-C and Bluetooth, switched automatically

PLAYBACK
• Songs, albums, artists and folders with fast search
• Gapless playback, queue editing, shuffle and repeat
• Speed and pitch, sleep timer, skip silence
• Lock-screen, notification, Bluetooth and headset controls
• Resumes where you left off

LIVE TV
• Kenyan, African and international news channels
• Picture-in-picture, full screen and data-saver mode

LIVE RADIO
• Discover 50,000+ stations — filter by country (Kenya and more), language and genre
• Save favourites, add any station by link, see the song on air

LYRICS & INFO (optional, saved for offline use)
• Time-synced lyrics with tap-to-seek
• Missing cover art, genre and release year
• Artist biographies

PRIVATE BY DESIGN
• Works fully offline, no account needed
• No ads, no tracking, listening stats stay on your phone
• Asks before using the internet

**Category:** Music & Audio
**Content rating:** Everyone

